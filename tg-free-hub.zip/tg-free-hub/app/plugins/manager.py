"""Plugins = the part of the bot that can upgrade itself.

A plugin is ONE python file that defines `register(api)`. It can add commands, inline buttons,
main-menu buttons and scheduled tasks. Code lives in the database (versioned), is compiled from
memory, and a new registry replaces the old one atomically - so installing or rolling back never
needs a restart.

IMPORTANT: plugin code runs inside the bot process with full Python power. The checker warns about
dangerous code, but you must still read what you approve (see SELFDEV_HE.md).
"""
import asyncio
import json
import linecache
import logging
import re
import time
import types
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable

from .. import files as filelib
from ..ai.router import AllProvidersFailed
from ..media import net
from ..telegram import TGError

log = logging.getLogger("plugins")

NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")
CMD_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
RESERVED_COMMANDS = {
    "start", "help", "reset", "search", "ai", "video", "dl", "clip", "jobs", "cancel", "providers", "addkey",
    "addprovider", "setmodel", "testai", "backup", "restore", "upgrade", "addcode", "versions", "rollback",
    "version", "check", "menu",
}


class PluginLoadError(Exception):
    def __init__(self, plugin: str, message: str):
        super().__init__(f"{plugin}: {message}")
        self.plugin = plugin
        self.message = message


@dataclass
class Registry:
    commands: dict = field(default_factory=dict)    # cmd -> (plugin, handler, help, admin_only)
    callbacks: dict = field(default_factory=dict)   # plugin -> handler
    menu: list = field(default_factory=list)        # (label, plugin, payload)
    every: list = field(default_factory=list)       # (plugin, seconds, handler)
    plugins: list = field(default_factory=list)


class PluginAPI:
    """What a plugin receives in register(api)."""

    def __init__(self, plugin: str, reg: Registry):
        self._p, self._r = plugin, reg

    def command(self, name: str, handler: Callable, help: str = "", admin_only: bool = False) -> None:
        if not CMD_RE.match(name):
            raise ValueError(f"bad command name {name!r} (a-z, 0-9, _)")
        if name in RESERVED_COMMANDS:
            raise ValueError(f"/{name} is a built-in command")
        if name in self._r.commands:
            raise ValueError(f"/{name} is already used by plugin {self._r.commands[name][0]}")
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError(f"handler of /{name} must be 'async def'")
        self._r.commands[name] = (self._p, handler, help, admin_only)

    def callback(self, handler: Callable) -> None:
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError("callback handler must be 'async def'")
        self._r.callbacks[self._p] = handler

    def menu(self, label: str, command: str | None = None, data: str | None = None) -> None:
        if bool(command) == bool(data):
            raise ValueError("menu(): give exactly one of command= or data=")
        self._r.menu.append((str(label)[:30], self._p, f"cmd:{command}" if command else f"data:{data}"))

    def every(self, seconds: float, handler: Callable) -> None:
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError("scheduled handler must be 'async def'")
        self._r.every.append((self._p, max(30.0, float(seconds)), handler))


class PluginContext:
    """What a plugin handler receives. Small on purpose."""

    def __init__(self, hub, plugin: str, user_id: int, chat_id: int, args: str = "", data: str = ""):
        self._hub = hub
        self._plugin = plugin
        self.user_id, self.chat_id = user_id, chat_id
        self.args, self.data = args, data

    @property
    def args_list(self) -> list[str]:
        return self.args.split()

    @property
    def is_admin(self) -> bool:
        return self._hub.is_admin(self.user_id)

    async def reply(self, text: str, buttons: list | None = None) -> None:
        """buttons = [[("תווית", "data")], [("אתר", "https://...")]] - rows of (label, data|url)."""
        markup = None
        if buttons:
            rows = []
            for row in buttons:
                out = []
                for label, payload in row:
                    if str(payload).startswith(("http://", "https://")):
                        out.append({"text": str(label)[:40], "url": payload})
                    else:
                        out.append({"text": str(label)[:40], "callback_data": f"x:{self._plugin}:{payload}"[:64]})
                rows.append(out)
            markup = {"inline_keyboard": rows}
        await self._hub.tg.send_message(self.chat_id, str(text), **({"reply_markup": markup} if markup else {}))

    async def ai(self, prompt: str, system: str = "") -> str:
        self._hub.rate_limit(self.user_id)
        try:
            res = await self._hub.router.chat([{"role": "user", "content": str(prompt)[:6000]}],
                                              system=system or "ענה בקצרה ובעברית.", max_tokens=800)
        except AllProvidersFailed:
            raise RuntimeError("מנועי ה-AI לא זמינים כרגע")
        return res.text

    async def http_get(self, url: str, max_bytes: int = 2_000_000) -> str:
        """Safe GET: public http(s) addresses only, 15s timeout, size-capped. Returns text."""
        net.check_url(url)

        def go():
            req = urllib.request.Request(url, headers={"User-Agent": "hub-plugin"})
            try:
                with urllib.request.urlopen(req, timeout=15) as r:
                    return r.read(max_bytes).decode("utf-8", "replace")
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                raise RuntimeError(f"הבקשה נכשלה: {getattr(e, 'reason', e)}")
        return await asyncio.to_thread(go)

    def search(self, query: str, limit: int = 10) -> list[dict]:
        return filelib.search(self._hub.db, query, limit)

    async def send_file(self, file_db_id: int) -> None:
        await filelib.send_file(self._hub.tg, self._hub.db, int(file_db_id), self.chat_id, self._hub.s.send_mode)

    def store_get(self, key: str, default=None):
        raw = self._hub.db.meta_get(f"plug:{self._plugin}:{key}", "")
        return json.loads(raw) if raw else default

    def store_set(self, key: str, value) -> None:
        self._hub.db.meta_set(f"plug:{self._plugin}:{key}", json.dumps(value, ensure_ascii=False))

    async def notify_admins(self, text: str) -> None:
        for a in sorted(self._hub.s.admin_ids):
            try:
                await self._hub.tg.send_message(a, str(text))
            except TGError:
                pass


class PluginManager:
    def __init__(self, hub):
        self.hub = hub
        self.registry = Registry()
        self.files: dict[str, str] = {}
        self.errors: list[float] = []          # error timestamps since the last activation
        self.on_error = None                   # async (plugin, exc, where) -> None  (set by SelfDev)
        self._tasks: list[asyncio.Task] = []

    # ------------------------------------------------------------ loading
    @staticmethod
    def build(files: dict[str, str]) -> Registry:
        reg = Registry()
        for name, code in sorted(files.items()):
            if not NAME_RE.match(name):
                raise PluginLoadError(name, "שם תוסף לא חוקי (a-z, 0-9, _ ; 2-31 תווים)")
            fn = f"<plugin:{name}>"
            try:
                compiled = compile(code, fn, "exec")
            except SyntaxError as e:
                raise PluginLoadError(name, f"שגיאת תחביר בשורה {e.lineno}: {e.msg}")
            linecache.cache[fn] = (len(code), None, code.splitlines(True), fn)
            mod = types.ModuleType(f"plugin_{name}")
            try:
                exec(compiled, mod.__dict__)  # noqa: S102 - by design, after admin approval
            except Exception as e:  # noqa: BLE001
                raise PluginLoadError(name, f"שגיאה בטעינה: {type(e).__name__}: {e}")
            fn_reg = mod.__dict__.get("register")
            if not callable(fn_reg):
                raise PluginLoadError(name, "חסרה הפונקציה register(api)")
            try:
                fn_reg(PluginAPI(name, reg))
            except Exception as e:  # noqa: BLE001
                raise PluginLoadError(name, f"register() נכשלה: {type(e).__name__}: {e}")
            reg.plugins.append(name)
        return reg

    async def activate(self, files: dict[str, str]) -> None:
        """Validate, then atomically swap. Raises PluginLoadError and leaves the running set untouched."""
        reg = self.build(files)
        for t in self._tasks:
            t.cancel()
        self._tasks.clear()
        self.registry, self.files, self.errors = reg, dict(files), []
        for plugin, seconds, handler in reg.every:
            self._tasks.append(asyncio.create_task(self._scheduler(plugin, seconds, handler)))

    async def _scheduler(self, plugin: str, seconds: float, handler) -> None:
        admin = sorted(self.hub.s.admin_ids)[0] if self.hub.s.admin_ids else 0
        while True:
            await asyncio.sleep(seconds)
            await self._safe(plugin, handler(PluginContext(self.hub, plugin, admin, admin)), "משימה מתוזמנת")

    # ------------------------------------------------------------ dispatch
    async def _safe(self, plugin: str, coro, where: str, notify_chat: int | None = None) -> None:
        try:
            await asyncio.wait_for(coro, 60)
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001 - a plugin must never take the bot down
            self.errors.append(time.time())
            log.warning("plugin %s failed in %s: %r", plugin, where, e)
            if notify_chat:
                try:
                    await self.hub.tg.send_message(notify_chat, f"⚠️ אירעה שגיאה בתוסף {plugin}. המנהל קיבל פירוט.")
                except TGError:
                    pass
            if self.on_error:
                await self.on_error(plugin, e, where)

    async def dispatch_command(self, cmd: str, uid: int, chat: int, args: str) -> bool:
        entry = self.registry.commands.get(cmd)
        if not entry:
            return False
        plugin, handler, _help, admin_only = entry
        if admin_only and not self.hub.is_admin(uid):
            await self.hub.tg.send_message(chat, "הפקודה הזאת למנהלים בלבד.")
            return True
        await self._safe(plugin, handler(PluginContext(self.hub, plugin, uid, chat, args=args)), f"/{cmd}", chat)
        return True

    async def dispatch_callback(self, plugin: str, uid: int, chat: int, data: str) -> bool:
        if data.startswith("cmd:") and plugin:
            return await self.dispatch_command(data[4:], uid, chat, "")
        if data.startswith("data:"):
            data = data[5:]
        handler = self.registry.callbacks.get(plugin)
        if not handler:
            return False
        await self._safe(plugin, handler(PluginContext(self.hub, plugin, uid, chat, data=data)), f"כפתור {data[:20]}", chat)
        return True

    def menu_rows(self, is_admin: bool) -> list[list[dict]]:
        rows = []
        for label, plugin, payload in self.registry.menu:
            if payload.startswith("cmd:"):
                entry = self.registry.commands.get(payload[4:])
                if entry and entry[3] and not is_admin:
                    continue
            rows.append([{"text": label, "callback_data": f"x:{plugin}:{payload}"[:64]}])
        return rows
