"""Sandbox test runner. Executed in a SEPARATE python process (python -I harness.py) with a minimal
environment (no tokens, no keys), a temp working dir and CPU/memory limits. It loads a plugin
against a FAKE api, calls every command / button / scheduled handler with sample input, and prints
a JSON report. It never talks to Telegram or the network (all context methods are fakes).

stdin : {"code": str, "name": str, "reserved": [str]}
stdout: {"register_error": str|null, "findings": [...], "stats": {...}}
"""
import asyncio
import json
import linecache
import re
import sys
import traceback
import types

try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (25, 25))
    resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
except Exception:  # noqa: BLE001 - not available everywhere (Windows)
    pass

CMD_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")


class FakeCtx:
    def __init__(self, plugin, args="", data="", store=None):
        self.user_id = self.chat_id = 1
        self.args, self.data, self.is_admin = args, data, True
        self.replies, self._store = [], store if store is not None else {}

    @property
    def args_list(self):
        return self.args.split()

    async def reply(self, text, buttons=None):
        if not isinstance(text, str):
            raise TypeError(f"reply() expects str, got {type(text).__name__}")
        if buttons:
            for row in buttons:
                for item in row:
                    if len(item) != 2:
                        raise ValueError("each button must be (label, data)")
        self.replies.append(text)

    async def ai(self, prompt, system=""):
        return "תשובת בדיקה"

    async def http_get(self, url, max_bytes=2_000_000):
        return "{}"

    def search(self, query, limit=10):
        return []

    async def send_file(self, file_db_id):
        return None

    def store_get(self, key, default=None):
        return self._store.get(key, default)

    def store_set(self, key, value):
        json.dumps(value)          # must be JSON-serialisable, as in production
        self._store[key] = value

    async def notify_admins(self, text):
        self.replies.append("[admin] " + str(text))


class FakeAPI:
    def __init__(self, reserved):
        self.commands, self.callback_h, self.menus, self.everys, self.reserved = {}, None, [], [], set(reserved)

    def command(self, name, handler, help="", admin_only=False):
        if not CMD_RE.match(name):
            raise ValueError(f"bad command name {name!r}")
        if name in self.reserved:
            raise ValueError(f"/{name} is a built-in command")
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError(f"handler of /{name} must be 'async def'")
        self.commands[name] = handler

    def callback(self, handler):
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError("callback handler must be 'async def'")
        self.callback_h = handler

    def menu(self, label, command=None, data=None):
        if bool(command) == bool(data):
            raise ValueError("menu(): give exactly one of command= or data=")
        self.menus.append((label, command, data))

    def every(self, seconds, handler):
        if not asyncio.iscoroutinefunction(handler):
            raise ValueError("scheduled handler must be 'async def'")
        self.everys.append(handler)


def frames(exc, plugin):
    """Only the frames that belong to the plugin, as 'line N: code'."""
    out = []
    for fs in traceback.extract_tb(exc.__traceback__):
        if fs.filename == f"<plugin:{plugin}>":
            out.append(f"שורה {fs.lineno}: {(fs.line or '').strip()}")
    return out[-3:]


async def run_one(plugin, label, coro, findings, ctx=None):
    """Returns 'timeout' / 'exception' / None so the caller can stop repeating a hopeless handler."""
    try:
        await asyncio.wait_for(coro, 5)
        if ctx is not None and not ctx.replies:
            findings.append({"kind": "silent", "where": label,
                             "message": "הטיפול הסתיים בלי לשלוח שום תגובה למשתמש", "frames": []})
    except asyncio.TimeoutError:
        findings.append({"kind": "timeout", "where": label,
                         "message": "לא הסתיים תוך 5 שניות (תקוע או איטי מדי)", "frames": []})
        return "timeout"
    except Exception as e:  # noqa: BLE001
        findings.append({"kind": "exception", "where": label, "message": f"{type(e).__name__}: {e}",
                         "frames": frames(e, plugin)})
        return "exception"
    return None


async def main():
    spec = json.loads(sys.stdin.read())
    code, name = spec["code"], spec["name"]
    report = {"register_error": None, "findings": [], "stats": {}}
    linecache.cache[f"<plugin:{name}>"] = (len(code), None, code.splitlines(True), f"<plugin:{name}>")
    mod = types.ModuleType("plugin_under_test")
    api = FakeAPI(spec.get("reserved", []))
    try:
        exec(compile(code, f"<plugin:{name}>", "exec"), mod.__dict__)
        reg = mod.__dict__.get("register")
        if not callable(reg):
            raise RuntimeError("חסרה הפונקציה register(api)")
        reg(api)
    except BaseException as e:  # noqa: BLE001
        report["register_error"] = f"{type(e).__name__}: {e}"
        report["findings"].append({"kind": "register", "where": "register()", "message": report["register_error"],
                                   "frames": frames(e, name)})
        print(json.dumps(report, ensure_ascii=False))
        return
    store = {}
    for cmd, h in api.commands.items():
        for args in ("", "test", "1 2 3", "שלום עולם", "x" * 500):
            ctx = FakeCtx(name, args=args, store=store)
            if await run_one(name, f"/{cmd} עם הקלט {args[:20]!r}", h(ctx), report["findings"], ctx) == "timeout":
                break
    if api.callback_h:
        for data in ("x", "", "1", "שלום"):
            ctx = FakeCtx(name, data=data, store=store)
            if await run_one(name, f"כפתור עם data={data!r}", api.callback_h(ctx), report["findings"], ctx) == "timeout":
                break
    for h in api.everys:
        ctx = FakeCtx(name, store=store)
        await run_one(name, "משימה מתוזמנת", h(ctx), report["findings"])
    for label, command, data in api.menus:
        if command and command not in api.commands:
            report["findings"].append({"kind": "menu", "where": f"כפתור תפריט '{label}'",
                                       "message": f"מפנה לפקודה /{command} שלא קיימת בתוסף", "frames": []})
        if data and not api.callback_h:
            report["findings"].append({"kind": "menu", "where": f"כפתור תפריט '{label}'",
                                       "message": "יש כפתור עם data אבל לא הוגדר api.callback(...)", "frames": []})
    report["stats"] = {"commands": len(api.commands), "callbacks": bool(api.callback_h),
                       "menus": len(api.menus), "scheduled": len(api.everys)}
    # de-duplicate identical findings (same message from several sample inputs)
    seen, uniq = set(), []
    for f in report["findings"]:
        key = (f["kind"], f["message"], tuple(f["frames"]))
        if key not in seen:
            seen.add(key)
            uniq.append(f)
    report["findings"] = uniq
    print(json.dumps(report, ensure_ascii=False))


try:
    asyncio.run(main())
except BaseException as e:  # noqa: BLE001
    print(json.dumps({"register_error": f"harness crashed: {type(e).__name__}: {e}", "findings": [], "stats": {}}))
