import hashlib
import os
from dataclasses import dataclass, field


def _ids(raw: str) -> set[int]:
    out = set()
    for part in (raw or "").replace(";", ",").split(","):
        part = part.strip()
        if part.lstrip("-").isdigit():
            out.add(int(part))
    return out


@dataclass
class Settings:
    bot_token: str = ""
    admin_ids: set[int] = field(default_factory=set)
    allowed_ids: set[int] = field(default_factory=set)
    allow_public: bool = False
    secret_key: str = "dev-secret-change-me"
    public_url: str = ""
    db_path: str = "data/hub.db"
    send_mode: str = "copy"
    context_messages: int = 10
    ai_timeout: float = 45.0
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    ai_keys_seed: str = ""
    enable_downloads: bool = True
    download_admin_only: bool = True
    video_admin_only: bool = False
    max_download_mb: int = 400
    tg_api_id: int = 0
    tg_api_hash: str = ""
    work_dir: str = ""
    video_brand: str = ""
    ai_rate_per_min: int = 20
    max_active_jobs: int = 3

    @property
    def webhook_path(self) -> str:
        h = hashlib.sha256(("wh:" + self.bot_token + self.secret_key).encode()).hexdigest()[:24]
        return f"/webhook/{h}"

    @property
    def webhook_secret(self) -> str:
        return hashlib.sha256(("sec:" + self.bot_token + self.secret_key).encode()).hexdigest()[:32]


def load_settings() -> Settings:
    e = os.environ.get
    return Settings(
        bot_token=e("BOT_TOKEN", ""),
        admin_ids=_ids(e("ADMIN_IDS", "")),
        allowed_ids=_ids(e("ALLOWED_USER_IDS", "")),
        allow_public=e("ALLOW_PUBLIC", "false").lower() == "true",
        secret_key=e("SECRET_KEY", "dev-secret-change-me"),
        public_url=e("PUBLIC_URL", "").rstrip("/"),
        db_path=e("DATABASE_PATH", "data/hub.db"),
        send_mode=e("SEND_MODE", "copy"),
        context_messages=int(e("CHAT_CONTEXT_MESSAGES", "10")),
        ai_timeout=float(e("AI_TIMEOUT_SECONDS", "45")),
        cors_origins=[o.strip() for o in e("CORS_ORIGINS", "*").split(",") if o.strip()],
        ai_keys_seed=e("AI_KEYS_SEED", ""),
        enable_downloads=e("ENABLE_DOWNLOADS", "true").lower() == "true",
        download_admin_only=e("DOWNLOAD_ADMIN_ONLY", "true").lower() == "true",
        video_admin_only=e("VIDEO_ADMIN_ONLY", "false").lower() == "true",
        max_download_mb=int(e("MAX_DOWNLOAD_MB", "400")),
        tg_api_id=int(e("TG_API_ID", "0") or 0),
        tg_api_hash=e("TG_API_HASH", ""),
        work_dir=e("WORK_DIR", ""),
        video_brand=e("VIDEO_BRAND", ""),
        ai_rate_per_min=int(e("AI_RATE_PER_MIN", "20")),
        max_active_jobs=int(e("MAX_ACTIVE_JOBS", "3")),
    )
