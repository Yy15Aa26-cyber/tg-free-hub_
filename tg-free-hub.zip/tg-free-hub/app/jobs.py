"""Background jobs (downloads, clips, AI videos). One heavy job at a time: free hosts have ~512MB RAM."""
import asyncio
import logging
import os
import shutil
import tempfile
import time
from dataclasses import dataclass, field

from . import files as filelib
from .ai.router import AllProvidersFailed
from .hub import Hub
from .media import mtproto, net, video
from .media.common import MediaError, safe_name
from .telegram import TGError

log = logging.getLogger("jobs")
BOT_API_LIMIT = 49 * 2**20
BIG_LIMIT = 1900 * 2**20     # MTProto bot uploads: Telegram hard cap is 2GB per file
MAX_PARTS_WITHOUT_MTPROTO = 30
NO_LIMIT_MB = 10**7


@dataclass
class Job:
    id: int
    kind: str
    user_id: int
    label: str
    status: str = "queued"       # queued | running | done | failed | cancelled
    detail: str = ""
    created: float = field(default_factory=time.time)
    task: asyncio.Task | None = None

    def public(self) -> dict:
        return {"id": self.id, "kind": self.kind, "label": self.label[:80], "status": self.status,
                "detail": self.detail, "age": int(time.time() - self.created)}


class JobError(Exception):
    pass


class Jobs:
    def __init__(self, hub: Hub):
        self.hub = hub
        self.s = hub.s
        self.tg = hub.tg
        self.sem = asyncio.Semaphore(1)
        self.items: dict[int, Job] = {}
        self._n = 0

    # ------------------------------------------------------------ public api
    def list(self, uid: int) -> list[dict]:
        return [j.public() for j in sorted(self.items.values(), key=lambda j: -j.id) if j.user_id == uid][:15]

    def cancel(self, uid: int, jid: int) -> bool:
        j = self.items.get(jid)
        if not j or j.user_id != uid or j.status not in ("queued", "running"):
            return False
        if j.task:
            j.task.cancel()
        return True

    def start_download(self, uid: int, url: str, audio: bool = False) -> Job:
        if not self.s.enable_downloads:
            raise JobError("ההורדות כבויות בשרת הזה.")
        if self.s.download_admin_only and not self.hub.is_admin(uid):
            raise JobError("הורדה מקישורים זמינה למנהלים בלבד.")
        net.check_url(url)  # fail fast, before queueing
        return self._start("download", uid, url, lambda j, d: self._do_download(j, d, url, audio))

    def start_clip(self, uid: int, url: str, start: str, end: str) -> Job:
        if self.s.download_admin_only and not self.hub.is_admin(uid):
            raise JobError("חיתוך קטעים מקישורים זמין למנהלים בלבד.")
        net.check_url(url)
        return self._start("clip", uid, f"{url} [{start}-{end}]", lambda j, d: self._do_clip(j, d, url, start, end))

    def start_video(self, uid: int, topic: str, lang: str = "he", scenes: int = 6, style: str = "") -> Job:
        if self.s.video_admin_only and not self.hub.is_admin(uid):
            raise JobError("יצירת וידאו זמינה למנהלים בלבד.")
        topic = topic.strip()[:300]
        if len(topic) < 3:
            raise JobError("כתוב נושא לוידאו.")
        scenes = min(max(int(scenes), 3), 10)
        return self._start("video", uid, topic, lambda j, d: self._do_video(j, d, topic, lang, scenes, style))

    # ------------------------------------------------------------ plumbing
    def _start(self, kind, uid, label, fn) -> Job:
        active = [j for j in self.items.values() if j.user_id == uid and j.status in ("queued", "running")]
        cap = self.s.max_active_jobs
        if cap > 0 and len(active) >= cap:
            raise JobError(f"יש לך כבר {cap} משימות פעילות. המתן שיסתיימו או בטל עם /cancel.")
        self._n += 1
        job = Job(self._n, kind, uid, label)
        self.items[job.id] = job
        for old in sorted(self.items)[:-40]:
            self.items.pop(old, None)
        job.task = asyncio.create_task(self._run(job, fn))
        return job

    async def _notify(self, uid: int, text: str):
        try:
            await self.tg.send_message(uid, text)
        except TGError as e:
            log.warning("notify failed: %s", e)

    async def _run(self, job: Job, fn):
        workdir = None
        try:
            async with self.sem:
                job.status = "running"
                base = self.s.work_dir or None
                if base:
                    os.makedirs(base, exist_ok=True)
                workdir = tempfile.mkdtemp(prefix="job", dir=base)
                await fn(job, workdir)
            job.status = "done"
        except asyncio.CancelledError:
            job.status = "cancelled"
            job.detail = "בוטל"
            await self._notify(job.user_id, f"🛑 משימה {job.id} בוטלה.")
        except (MediaError, JobError) as e:
            job.status, job.detail = "failed", str(e)
            await self._notify(job.user_id, f"❌ משימה {job.id} נכשלה: {e}")
        except AllProvidersFailed:
            job.status, job.detail = "failed", "אין מנוע AI זמין"
            await self._notify(job.user_id, f"❌ משימה {job.id}: כל מנועי ה-AI לא זמינים כרגע.")
        except TGError as e:
            job.status, job.detail = "failed", "שליחה לטלגרם נכשלה"
            await self._notify(job.user_id, f"❌ משימה {job.id}: השליחה נכשלה ({e.description[:100]}). שלחת /start לבוט?")
        except Exception as e:  # noqa: BLE001
            log.exception("job crashed")
            await self.hub.monitor.report(e, f"משימה {job.kind} #{job.id}")
            job.status, job.detail = "failed", "שגיאה פנימית"
            await self._notify(job.user_id, f"❌ משימה {job.id} נכשלה בגלל שגיאה פנימית.")
        finally:
            if workdir:
                shutil.rmtree(workdir, ignore_errors=True)

    # ------------------------------------------------------------ upload
    async def _send_one(self, uid, path, caption, as_video, mt) -> dict:
        if os.path.getsize(path) <= BOT_API_LIMIT:
            return await self.tg.send_file_path(uid, path, caption, as_video)
        return await mtproto.send_big(self.s.tg_api_id, self.s.tg_api_hash, self.s.bot_token,
                                      uid, path, caption, as_video)

    async def deliver(self, uid: int, path: str, caption: str, as_video: bool = False, index: bool = False):
        """Any size: <=50MB plain Bot API; <=2GB via MTProto (if configured); anything bigger is split into parts."""
        size = os.path.getsize(path)
        mt = mtproto.configured(self.s.tg_api_id, self.s.tg_api_hash)
        is_video = path.lower().endswith((".mp4", ".mkv", ".mov", ".webm", ".avi"))
        limit = BIG_LIMIT if mt else BOT_API_LIMIT
        sent: list[dict] = []
        if size <= limit:
            sent.append(await self._send_one(uid, path, caption, as_video, mt))
        else:
            if is_video:   # cut by time, no re-encode: every part stays playable on its own
                parts = await net.split_video(path, int(limit * 0.9), limit)
            else:          # binary parts: joined later with  cat name.* > name
                part_bytes = int(limit * 0.95)
                n = -(-size // part_bytes)
                if not mt and n > MAX_PARTS_WITHOUT_MTPROTO:
                    raise MediaError(f"הקובץ ({size // 2**20}MB) יתפצל ליותר מ-{MAX_PARTS_WITHOUT_MTPROTO} חלקים. "
                                     "הגדר TG_API_ID ו-TG_API_HASH והתקן pyrogram כדי לשלוח חלקים של עד 2GB.")
                parts = await net.split_file(path, part_bytes)
            for i, p in enumerate(parts, 1):
                note = f"{caption}\n(חלק {i}/{len(parts)})"
                if not is_video:
                    note += f"\nאיחוד: cat {os.path.basename(path)}.* > {os.path.basename(path)}"
                sent.append(await self._send_one(uid, p, note, as_video, mt))
        if index:
            for m in sent:
                filelib.index_message(self.hub.db, m)
        return sent

    # ------------------------------------------------------------ job bodies
    async def _do_download(self, job: Job, workdir: str, url: str, audio: bool):
        job.detail = "מוריד…"

        def progress(done, total):
            job.detail = f"מוריד… {done // 2**20}MB" + (f" מתוך {total // 2**20}MB" if total else "")

        path = await net.fetch(url, workdir, self.s.max_download_mb or NO_LIMIT_MB, audio, progress)
        job.detail = "מעלה לטלגרם…"
        name = os.path.basename(path)
        await self.deliver(job.user_id, path, name, as_video=False, index=True)
        job.detail = name
        await self._notify(job.user_id, f"✅ הורדה הסתיימה: {name}\nהקובץ נוסף גם לספרייה (/search).")

    async def _do_clip(self, job: Job, workdir: str, url: str, start: str, end: str):
        job.detail = "מוריד את המקור…"
        src = await net.fetch(url, workdir, self.s.max_download_mb or NO_LIMIT_MB)
        job.detail = "חותך…"
        out = await net.cut_clip(src, start, end, os.path.join(workdir, "clip.mp4"))
        job.detail = "מעלה…"
        await self.deliver(job.user_id, out, f"קטע {start}-{end}", as_video=True)
        await self._notify(job.user_id, "✅ הקטע מוכן.")

    async def _do_video(self, job: Job, workdir: str, topic: str, lang: str, scenes: int, style: str):
        job.detail = "כותב תסריט…"
        script = await video.write_script(self.hub.router, topic, lang, scenes, style)
        out = await video.make_video(script, workdir, brand=self.s.video_brand,
                                     progress=lambda m: setattr(job, "detail", m))
        job.detail = "מעלה…"
        await self.deliver(job.user_id, out, video.caption_for(script), as_video=True)
        job.detail = script.title
        await self._notify(job.user_id, "✅ הוידאו מוכן. הכותרת, התיאור והתגיות נמצאים בכיתוב שלו.")
