"""Version store. Every installed upgrade becomes a new version:
n=1 -> 0.1, n=2 -> 0.2 ... n=10 -> 1.0, n=11 -> 1.1 ... n=20 -> 2.0.  Version 0.0 = no plugins (the base bot)."""
import json
import re
import time

from ..db import DB


def label(n: int) -> str:
    return f"{n // 10}.{n % 10}"


def parse_label(text: str) -> int | None:
    m = re.fullmatch(r"v?(\d+)\.(\d)", text.strip().lower())
    return int(m.group(1)) * 10 + int(m.group(2)) if m else None


class VersionStore:
    def __init__(self, db: DB):
        self.db = db

    def active(self) -> int:
        v = self.db.meta_get("active_version", "0")
        return int(v) if v.isdigit() else 0

    def set_active(self, n: int) -> None:
        self.db.meta_set("active_version", str(n))

    def get_files(self, n: int) -> dict[str, str]:
        if n == 0:
            return {}
        r = self.db.one("SELECT files FROM versions WHERE n=?", (n,))
        if not r:
            raise KeyError(f"version {label(n)} not found")
        return json.loads(r["files"])

    def get(self, n: int) -> dict | None:
        r = self.db.one("SELECT * FROM versions WHERE n=?", (n,))
        return dict(r) if r else None

    def next_n(self) -> int:
        r = self.db.one("SELECT COALESCE(MAX(n),0)+1 AS n FROM versions")
        return r["n"]

    def create(self, files: dict[str, str], description: str, source: str, parent: int) -> int:
        n = self.next_n()
        self.db.x("INSERT INTO versions(n,label,created,description,files,parent,source) VALUES(?,?,?,?,?,?,?)",
                  (n, label(n), time.time(), description[:300], json.dumps(files, ensure_ascii=False), parent, source))
        return n

    def list(self) -> list[dict]:
        rows = self.db.q("SELECT n,label,created,description,parent,source FROM versions ORDER BY n DESC")
        return [dict(r) for r in rows]
