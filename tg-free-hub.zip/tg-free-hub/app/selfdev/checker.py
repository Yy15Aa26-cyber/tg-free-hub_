"""Bug finder for plugin code (and the core).  Three layers, merged into one report:

1. static   - parses the code (ast) and looks for known problems, each with a plain-language impact
2. sandbox  - runs the plugin in a separate process against a fake API with sample inputs
3. ai       - an LLM review (optional; labelled as an estimate, never as certain)

No layer can prove the code is bug-free. A clean report means "nothing found", not "nothing there".
"""
import ast
import asyncio
import builtins
import json
import os
import re
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from ..plugins.manager import RESERVED_COMMANDS

HARNESS = Path(__file__).resolve().parent.parent / "plugins" / "harness.py"
SEV_ORDER = {"critical": 0, "high": 1, "security": 2, "medium": 3, "low": 4}
SEV_LABEL = {"critical": "🔴 קריטי", "high": "🟠 חמור", "security": "⚠️ אבטחה", "medium": "🟡 בינוני", "low": "⚪ קל"}

SAFE_IMPORTS = {
    "json", "re", "math", "datetime", "time", "random", "itertools", "collections", "functools", "typing",
    "asyncio", "string", "textwrap", "html", "base64", "hashlib", "uuid", "decimal", "fractions", "statistics",
    "zoneinfo", "enum", "dataclasses", "operator", "copy", "urllib.parse", "calendar", "unicodedata", "heapq",
    "bisect", "secrets", "difflib", "numbers", "__future__", "abc",
}
DANGEROUS_MODULES = {
    "os": "להריץ פקודות, לקרוא משתני סביבה (כולל מפתחות) ולמחוק קבצים", "sys": "לגשת לפנימיות של התוכנה",
    "subprocess": "להריץ כל פקודה על המכשיר/השרת", "shutil": "להעתיק ולמחוק קבצים",
    "socket": "לפתוח חיבורי רשת חופשיים", "ctypes": "לגשת לזיכרון ולמערכת ההפעלה",
    "pickle": "להריץ קוד שרירותי בזמן טעינת נתונים", "marshal": "להריץ קוד שרירותי", "importlib": "לטעון קוד אחר",
    "builtins": "לעקוף הגנות", "inspect": "לקרוא את הקוד ואת המשתנים של הבוט", "gc": "לגשת לכל האובייקטים בזיכרון",
    "signal": "להפריע לתהליך", "multiprocessing": "להפעיל תהליכים נוספים", "pathlib": "לקרוא ולכתוב קבצים",
    "tempfile": "לכתוב קבצים", "glob": "לסרוק קבצים", "sqlite3": "לגשת ישירות למסד (כולל המפתחות)",
    "http": "גישת רשת חופשית", "ftplib": "גישת רשת חופשית", "smtplib": "לשלוח מיילים", "requests": "גישת רשת חופשית",
    "httpx": "גישת רשת חופשית", "aiohttp": "גישת רשת חופשית", "urllib.request": "גישת רשת חופשית",
    "threading": "להפעיל תהליכונים שלא נשלטים", "app": "לגשת לקוד הפנימי של הבוט, כולל המפתחות",
}
DANGEROUS_CALLS = {
    "eval": "להריץ טקסט כקוד", "exec": "להריץ טקסט כקוד", "compile": "לקמפל קוד בזמן ריצה",
    "__import__": "לטעון כל מודול", "open": "לקרוא ולכתוב קבצים (כולל .env עם המפתחות)",
    "input": "לחסום את הבוט עד קלט שלא יגיע", "breakpoint": "לעצור את הבוט",
}
SECRET_WORDS = ("BOT_TOKEN", "SECRET_KEY", "TG_API_HASH", ".env", "hub.db")


@dataclass
class Issue:
    severity: str
    title: str
    detail: str = ""
    impact: str = ""
    where: str = ""
    source: str = "static"          # static | sandbox | ai

    def to_dict(self):
        return self.__dict__.copy()


def sort_issues(issues: list[Issue]) -> list[Issue]:
    return sorted(issues, key=lambda i: SEV_ORDER.get(i.severity, 9))


def blocks_install(issues: list[Issue]) -> bool:
    """True when the plugin cannot even load (so 'install anyway' makes no sense)."""
    return any(i.severity == "critical" for i in issues)


# ---------------------------------------------------------------------- static
def static_check(code: str, name: str = "plugin") -> list[Issue]:
    issues: list[Issue] = []
    try:
        tree = ast.parse(code)
        compile(code, f"<plugin:{name}>", "exec")
    except SyntaxError as e:
        return [Issue("critical", "שגיאת תחביר", f"{e.msg}", "הקוד לא ייטען בכלל, התוסף לא יותקן.",
                      f"שורה {e.lineno}")]
    except (ValueError, MemoryError) as e:
        return [Issue("critical", "הקוד לא תקין", str(e), "לא ניתן לטעון.")]

    # register(api)
    reg = [n for n in tree.body if isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef) and n.name == "register"]
    if not reg:
        issues.append(Issue("critical", "חסרה הפונקציה register(api)", "",
                            "בלעדיה הבוט לא יודע מה התוסף מוסיף, התוסף לא יעבוד."))
    elif isinstance(reg[0], ast.AsyncFunctionDef) or len(reg[0].args.args) != 1:
        issues.append(Issue("critical", "register חייבת להיות פונקציה רגילה עם פרמטר אחד: def register(api)", "",
                            "הטעינה תיכשל.", f"שורה {reg[0].lineno}"))

    # imports
    for node in ast.walk(tree):
        mods = []
        if isinstance(node, ast.Import):
            mods = [(a.name, node.lineno) for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            mods = [(node.module, node.lineno)]
        for mod, line in mods:
            full, top = mod, mod.split(".")[0]
            if full in DANGEROUS_MODULES or top in DANGEROUS_MODULES:
                what = DANGEROUS_MODULES.get(full) or DANGEROUS_MODULES[top]
                issues.append(Issue("security", f"ייבוא של {mod}", f"התוסף יוכל {what}.",
                                    "יכול לפגוע בבוט, במכשיר או לדלוף את המפתחות שלך.", f"שורה {line}"))
            elif full not in SAFE_IMPORTS and top not in SAFE_IMPORTS:
                issues.append(Issue("medium", f"ייבוא של {mod} (לא מהרשימה הבטוחה)",
                                    "ייתכן שהספרייה לא מותקנת בבוט, או שהיא נותנת גישות נוספות.",
                                    "אם היא לא מותקנת: התוסף יקרוס בטעינה.", f"שורה {line}"))

    # names that are used but never defined anywhere
    bound = set(dir(builtins)) | {"__name__", "__file__", "__doc__"}
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store | ast.Del):
            bound.add(n.id)
        elif isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
            bound.add(n.name)
            if not isinstance(n, ast.ClassDef):
                a = n.args
                for arg in a.posonlyargs + a.args + a.kwonlyargs + [x for x in (a.vararg, a.kwarg) if x]:
                    bound.add(arg.arg)
        elif isinstance(n, ast.Lambda):
            a = n.args
            for arg in a.posonlyargs + a.args + a.kwonlyargs + [x for x in (a.vararg, a.kwarg) if x]:
                bound.add(arg.arg)
        elif isinstance(n, ast.Import | ast.ImportFrom):
            for al in n.names:
                bound.add((al.asname or al.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
        elif isinstance(n, ast.Global | ast.Nonlocal):
            bound.update(n.names)
        elif isinstance(n, ast.MatchAs | ast.MatchStar) and n.name:
            bound.add(n.name)
    reported = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in bound and n.id not in reported:
            reported.add(n.id)
            issues.append(Issue("high", f"שימוש במשתנה שלא הוגדר: {n.id}", "",
                                "כשהשורה תרוץ תיזרק NameError והפקודה תיכשל.", f"שורה {n.lineno}"))

    # risky calls, blocking calls, loops
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            dotted = _dotted(f)
            if isinstance(f, ast.Name) and f.id in DANGEROUS_CALLS:
                issues.append(Issue("security", f"קריאה ל-{f.id}()", f"מאפשרת {DANGEROUS_CALLS[f.id]}.",
                                    "יכול לפגוע בבוט או לדלוף מפתחות.", f"שורה {n.lineno}"))
            if dotted in ("time.sleep",) or (isinstance(f, ast.Name) and f.id == "sleep"):
                issues.append(Issue("medium", "time.sleep() חוסם את כל הבוט",
                                    "ב-async צריך await asyncio.sleep(...).",
                                    "בזמן ההמתנה הבוט לא עונה לאף משתמש.", f"שורה {n.lineno}"))
            if dotted and dotted.split(".")[0] in ("requests", "urllib") and dotted.endswith(("get", "post", "urlopen")):
                issues.append(Issue("medium", f"{dotted}() היא קריאת רשת חוסמת",
                                    "להשתמש ב-await ctx.http_get(url) שהיא בטוחה ולא חוסמת.",
                                    "מקפיא את הבוט בזמן הבקשה.", f"שורה {n.lineno}"))
        if isinstance(n, ast.While) and isinstance(n.test, ast.Constant) and n.test.value is True:
            has_exit = any(isinstance(x, ast.Await | ast.Break | ast.Return | ast.Yield | ast.Raise)
                           for x in ast.walk(n))
            if not has_exit:
                issues.append(Issue("high", "לולאה אינסופית בלי await או break", "",
                                    "תקפיא את כל הבוט ואת כל המשתמשים עד הפעלה מחדש.", f"שורה {n.lineno}"))
        if isinstance(n, ast.ExceptHandler) and n.type is None:
            issues.append(Issue("low", "except: חשוף (בולע כל שגיאה)", "",
                                "תקלות יוסתרו ויהיה קשה לגלות למה משהו לא עובד.", f"שורה {n.lineno}"))
        if isinstance(n, ast.Attribute) and n.attr == "environ" and _dotted(n) == "os.environ":
            issues.append(Issue("security", "גישה ל-os.environ", "שם נמצאים הטוקן והמפתחות.",
                                "יכול לדלוף את BOT_TOKEN ואת SECRET_KEY.", f"שורה {n.lineno}"))
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            hit = next((w for w in SECRET_WORDS if w.lower() in n.value.lower()), None)
            if hit:
                issues.append(Issue("security", f"הקוד מזכיר '{hit}'", "ייתכן שהוא מנסה לקרוא סודות.",
                                    "דליפת מפתחות אפשרית.", f"שורה {n.lineno}"))

    # command names that collide with built-ins
    for n in ast.walk(tree):
        if (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "command"
                and n.args and isinstance(n.args[0], ast.Constant) and n.args[0].value in RESERVED_COMMANDS):
            issues.append(Issue("critical", f"הפקודה /{n.args[0].value} שמורה לבוט", "",
                                "הטעינה תיכשל. בחר שם פקודה אחר.", f"שורה {n.lineno}"))
    return _dedupe(issues)


def _dotted(node) -> str:
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return ""


def _dedupe(issues: list[Issue]) -> list[Issue]:
    seen, out = set(), []
    for i in issues:
        k = (i.severity, i.title, i.where)
        if k not in seen:
            seen.add(k)
            out.append(i)
    return out


# ---------------------------------------------------------------------- sandbox
async def sandbox_check(code: str, name: str, timeout: float = 40) -> list[Issue]:
    env = {k: os.environ[k] for k in ("PATH", "LD_LIBRARY_PATH", "LANG", "LC_ALL") if k in os.environ}
    with tempfile.TemporaryDirectory() as tmp:
        env.update(HOME=tmp, TMPDIR=tmp)
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-I", str(HARNESS), cwd=tmp, env=env,
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            out, err = await asyncio.wait_for(
                proc.communicate(json.dumps({"code": code, "name": name, "reserved": sorted(RESERVED_COMMANDS)}).encode()),
                timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return [Issue("high", "בדיקת הניסוי לא הסתיימה", "הקוד רץ יותר מדי זמן בסביבת הבדיקה.",
                          "כנראה לולאה אינסופית או פעולה כבדה מאוד.", source="sandbox")]
    try:
        report = json.loads(out.decode().strip().splitlines()[-1])
    except (ValueError, IndexError):
        tail = err.decode(errors="replace").strip().splitlines()[-1:] or [""]
        return [Issue("high", "הרצת הניסוי נכשלה", tail[0][:200], "לא ניתן היה לבדוק את הקוד בפועל.", source="sandbox")]
    issues = []
    for f in report.get("findings", []):
        where = f["where"] + ((" | " + " ; ".join(f["frames"])) if f.get("frames") else "")
        kind = f["kind"]
        if kind in ("exception", "register"):
            issues.append(Issue("critical" if kind == "register" else "high", "שגיאה בהרצה: " + f["message"], "",
                                "הטעינה נכשלת, התוסף לא יעבוד." if kind == "register"
                                else "הפקודה/הכפתור יקרסו למשתמש בכל פעם שהתנאי הזה מתקיים.", where, "sandbox"))
        elif kind == "timeout":
            issues.append(Issue("high", "פעולה תקועה", f["message"],
                                "המשתמש לא יקבל תשובה, והפעולה תיעצר אחרי דקה.", where, "sandbox"))
        elif kind == "silent":
            issues.append(Issue("low", "אין תגובה למשתמש", f["message"], "המשתמש לא יבין אם הפקודה עבדה.", where, "sandbox"))
        else:
            issues.append(Issue("medium", f["message"], "", "כפתור שלא יעבוד.", where, "sandbox"))
    return issues


# ---------------------------------------------------------------------- everything together
async def check_plugin(code: str, name: str, router=None, request: str = "") -> list[Issue]:
    issues = static_check(code, name)
    if not blocks_install(issues):
        issues += await sandbox_check(code, name)
    if router is not None:
        from .codegen import ai_review
        try:
            issues += await ai_review(router, code, name, request)
        except Exception:  # noqa: BLE001 - the AI layer is a bonus, never a blocker
            pass
    return sort_issues(_dedupe(issues))


def format_report(issues: list[Issue], name: str, used_ai: bool = True) -> str:
    if not issues:
        layers = "בדיקה סטטית, הרצת ניסוי" + (" וסקירת AI" if used_ai else "")
        return (f"✅ בדקתי את התוסף {name} ({layers}) ולא מצאתי באגים.\n"
                "שים לב: זה אומר שלא נמצא כלום, לא שהקוד מובטח נקי.")
    lines = [f"🔍 בדיקת התוסף {name}: נמצאו {len(issues)} ממצאים\n"]
    for i, it in enumerate(issues, 1):
        lines.append(f"{i}) {SEV_LABEL.get(it.severity, it.severity)} · {it.title}")
        if it.where:
            lines.append(f"   📍 {it.where}")
        if it.detail:
            lines.append(f"   ℹ️ {it.detail}")
        if it.impact:
            lines.append(f"   💥 משפיע על: {it.impact}")
        if it.source == "ai":
            lines.append("   🤖 הערכת AI, לא וודאי")
        lines.append("")
    if blocks_install(issues):
        lines.append("⛔ יש ממצא קריטי: התוסף לא ייטען, ולכן אי אפשר להתקין אותו כמו שהוא.")
    elif any(i.severity == "security" for i in issues):
        lines.append("⚠️ יש אזהרות אבטחה: אשר רק אם הקוד מגיע ממך או שקראת אותו.")
    return "\n".join(lines).strip()
