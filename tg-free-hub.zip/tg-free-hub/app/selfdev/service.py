"""Self-upgrade orchestration.  Everything happens ONLY on the admin's command and approval:

  /upgrade <what you want>   -> AI writes a plugin -> automatic bug check -> you decide
  /addcode <name> + code     -> same check for code you wrote yourself
  buttons: install / fix automatically (shown to you for approval) / I'll fix it myself / show code / cancel
  /versions  /rollback [x.y]  /version  /check

The one automatic action is a safety net: if a freshly installed version fails to load, or throws 3 errors
within 5 minutes of installation, the bot returns to the previous version and tells you.
"""
import asyncio
import logging
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..ai.router import AllProvidersFailed
from ..plugins.manager import NAME_RE, PluginLoadError
from ..telegram import TGError
from . import codegen
from .checker import Issue, blocks_install, check_plugin, format_report, sort_issues
from .versions import VersionStore, label, parse_label

log = logging.getLogger("selfdev")
ROOT = Path(__file__).resolve().parent.parent.parent
MAX_CODE = 60_000
AUTO_ROLLBACK_ERRORS = 3
AUTO_ROLLBACK_WINDOW = 300          # seconds
AUTO_ROLLBACK_AGE = 1800            # only versions installed in the last 30 min are rolled back automatically
SRC_ICON = {"ai": "🤖", "user": "👤", "fix": "🛠"}


@dataclass
class Draft:
    id: str
    name: str
    code: str
    description: str
    source: str                       # ai | user | fix
    request: str = ""
    issues: list = field(default_factory=list)
    orig_code: str = ""               # the code before an automatic fix (so you can go back to it)
    changes: list = field(default_factory=list)
    fixes: int = 0
    created: float = field(default_factory=time.time)


class SelfDev:
    def __init__(self, hub):
        self.hub = hub
        self.store = VersionStore(hub.db)
        self.drafts: dict[str, Draft] = {}
        self.last_error: dict[str, tuple[str, str]] = {}
        self.activated_at = 0.0
        self._n = 0
        hub.plugins.on_error = self.on_plugin_error

    # ------------------------------------------------------------------ helpers
    async def _say(self, chat: int, text: str, rows: list | None = None) -> None:
        kw = {"reply_markup": {"inline_keyboard": rows}} if rows else {}
        await self.hub.tg.send_message(chat, text, **kw)

    async def _admins(self, text: str) -> None:
        for a in sorted(self.hub.s.admin_ids):
            try:
                await self.hub.tg.send_message(a, text)
            except TGError:
                pass

    async def _send_code(self, chat: int, d: Draft, caption: str = "") -> None:
        await self.hub.tg.send_document_bytes(chat, f"{d.name}.py", d.code.encode(), caption[:900])

    def _ai_ready(self) -> bool:
        return self.hub.router.has_any_key()

    def active_label(self) -> str:
        return label(self.store.active())

    # ------------------------------------------------------------------ boot / health
    async def boot(self) -> None:
        """Load the active version. If it is broken, walk back to the newest one that loads."""
        n = self.store.active()
        tried = []
        candidates = [n] + [v["n"] for v in self.store.list() if v["n"] != n] + [0]
        for cand in dict.fromkeys(candidates):
            try:
                await self.hub.plugins.activate(self.store.get_files(cand))
            except (PluginLoadError, KeyError) as e:
                tried.append(f"{label(cand)}: {e}")
                continue
            self.activated_at = time.time()
            if cand != n:
                self.store.set_active(cand)
                await self._admins(f"🛡 הגרסה {label(n)} לא נטענה ({tried[0]}). חזרתי אוטומטית לגרסה {label(cand)}.")
            return
        log.error("no version could be loaded: %s", tried)

    # ------------------------------------------------------------------ create drafts
    def _new_draft(self, name: str, code: str, desc: str, source: str, request: str = "") -> Draft:
        self._n += 1
        d = Draft(f"d{self._n}", name, code, desc, source, request)
        self.drafts[d.id] = d
        for old in sorted(self.drafts, key=lambda k: self.drafts[k].created)[:-12]:
            self.drafts.pop(old, None)
        return d

    async def cmd_upgrade(self, uid: int, chat: int, text: str) -> None:
        if not self._ai_ready():
            return await self._say(chat, "כדי שאכתוב קוד צריך לפחות מפתח AI אחד (/addkey). "
                                         "או שתכתוב קוד בעצמך ותשלח עם /addcode.")
        m = re.match(r"name=([a-z][a-z0-9_]{1,30})\s+(.+)", text.strip(), re.S)
        existing_name, request = (m.group(1), m.group(2)) if m else ("", text.strip())
        if len(request) < 8:
            return await self._say(chat, "שימוש: /upgrade מה אתה רוצה שהבוט יוסיף\n"
                                         "לדוגמה: /upgrade פקודה /tip שנותנת טיפ יומי וכפתור בתפריט\n"
                                         "לעדכון תוסף קיים: /upgrade name=שם_התוסף מה לשנות")
        files = self.hub.plugins.files
        if existing_name and existing_name not in files:
            return await self._say(chat, f"אין תוסף בשם {existing_name}. /versions או /check מציגים את התוספים הפעילים.")
        await self._say(chat, "⏳ כותב את הקוד… (בדרך כלל חצי דקה)")
        try:
            name, summary, code = await codegen.write_plugin(
                self.hub.router, request, existing_name, files.get(existing_name, ""), list(files))
        except codegen.CodegenError as e:
            return await self._say(chat, f"❌ {e}")
        except AllProvidersFailed:
            return await self._say(chat, "❌ כל מנועי ה-AI לא זמינים כרגע. נסה שוב עוד רגע.")
        if name in files and not existing_name:          # never overwrite an existing plugin by accident
            name = f"{name}_{self._n + 1}"[:31]
        d = self._new_draft(name, code, summary, "ai", request)
        if existing_name:
            d.orig_code = files[existing_name]
        await self._present(chat, d, intro=f"📝 כתבתי תוסף {name}: {summary}\n")

    async def cmd_addcode(self, uid: int, chat: int, name: str, code: str) -> None:
        name = (name or "").strip().lower().removesuffix(".py")
        if not NAME_RE.match(name):
            return await self._say(chat, "שם התוסף חייב להיות באנגלית קטנה/ספרות/_ (2 עד 31 תווים).\n"
                                         "דוגמה: /addcode my_tip  ואחריו הקוד, או קובץ .py עם הכיתוב /addcode my_tip")
        if len(code) > MAX_CODE or not code.strip():
            return await self._say(chat, "הקוד ריק או גדול מדי (עד 60KB).")
        d = self._new_draft(name, code if code.endswith("\n") else code + "\n", f"קוד שלך ({name})", "user")
        if name in self.hub.plugins.files:
            d.orig_code = self.hub.plugins.files[name]
        await self._present(chat, d, intro="📥 קיבלתי את הקוד. בודק…\n")

    # ------------------------------------------------------------------ check + present
    async def _present(self, chat: int, d: Draft, intro: str = "") -> None:
        router = self.hub.router if self._ai_ready() else None
        d.issues = await check_plugin(d.code, d.name, router, d.request)
        report = format_report(d.issues, d.name, used_ai=router is not None)
        await self._say(chat, intro + report, self._buttons(d))

    def _buttons(self, d: Draft) -> list:
        rows = []
        if not blocks_install(d.issues):
            risky = any(i.severity == "security" for i in d.issues)
            word = "⚠️ התקן בכל זאת" if d.issues else "✅ התקן"
            rows.append([{"text": word + (" (אזהרת אבטחה)" if risky else ""), "callback_data": f"sd:inst:{d.id}"}])
        if d.issues:
            second = [{"text": "✏️ אתקן בעצמי", "callback_data": f"sd:self:{d.id}"}]
            if self._ai_ready() and d.fixes < 3:
                second.insert(0, {"text": "🛠 תקן לבד", "callback_data": f"sd:fix:{d.id}"})
            rows.append(second)
        if d.orig_code and d.source == "fix":
            rows.append([{"text": "↩️ חזור לקוד המקורי", "callback_data": f"sd:orig:{d.id}"}])
        rows.append([{"text": "👁 הצג קוד", "callback_data": f"sd:code:{d.id}"},
                     {"text": "🗑 בטל", "callback_data": f"sd:drop:{d.id}"}])
        return rows

    # ------------------------------------------------------------------ buttons
    async def on_callback(self, uid: int, chat: int, data: str) -> str:
        """data = 'sd:<action>:<arg>'. Returns a short toast text."""
        _, action, arg = (data.split(":", 2) + [""])[:3]
        if action == "rb":
            return await self.rollback(chat, "" if arg == "prev" else arg)
        if action == "fixplug":
            return await self._fix_running_plugin(chat, arg)
        d = self.drafts.get(arg)
        if not d:
            return "הטיוטה פגה (הבוט הופעל מחדש?). שלח את הבקשה שוב."
        if action == "drop":
            self.drafts.pop(d.id, None)
            return "בוטל. לא הותקן כלום."
        if action == "code":
            await self._send_code(chat, d, f"הקוד של {d.name}")
            return "נשלח"
        if action == "self":
            await self._send_code(chat, d, f"{d.name}.py")
            await self._say(chat, "✏️ ערוך את הקובץ ושלח אותו חזרה לכאן עם הכיתוב:\n"
                                  f"/addcode {d.name}\nאבדוק אותו שוב לפני שמשהו מותקן.")
            return "שלחתי לך את הקוד"
        if action == "orig":
            d.code, d.source, d.changes, d.fixes = d.orig_code, "user" if d.request == "" else "ai", [], 0
            await self._present(chat, d, intro="↩️ חזרתי לקוד המקורי.\n")
            return "הוחזר"
        if action == "fix":
            return await self._autofix(chat, d)
        if action == "inst":
            return await self._install(chat, d)
        return "פעולה לא מוכרת"

    async def _autofix(self, chat: int, d: Draft) -> str:
        actionable = [i for i in d.issues if i.severity != "low"] or d.issues
        if not actionable:
            return "אין מה לתקן."
        await self._say(chat, "🛠 מתקן… (שום דבר לא יותקן לפני שתאשר)")
        try:
            new_code, changes = await codegen.fix_plugin(self.hub.router, d.name, d.code, actionable)
        except (codegen.CodegenError, AllProvidersFailed) as e:
            await self._say(chat, f"❌ התיקון האוטומטי נכשל: {e if isinstance(e, codegen.CodegenError) else 'אין מנוע AI זמין'}")
            return "נכשל"
        if new_code.strip() == d.code.strip():
            await self._say(chat, "ה-AI לא שינה כלום, כנראה שאינו יודע לתקן את זה. אפשר לתקן בעצמך (✏️).")
            return "ללא שינוי"
        before, d.orig_code = d.code, d.orig_code or d.code
        d.code, d.source, d.changes, d.fixes = new_code, "fix", changes, d.fixes + 1
        d.issues = await check_plugin(d.code, d.name, self.hub.router, d.request)
        diff = codegen.make_diff(before, new_code)
        head = ("🛠 תיקנתי. הנה מה ששיניתי:\n" + "\n".join(f"• {c}" for c in changes) +
                f"\n\n📄 השוואה (לפני ← אחרי):\n{diff}\n\n")
        await self._say(chat, head + format_report(d.issues, d.name) +
                        "\n\nהקוד המתוקן עדיין לא מותקן. בחר מה לעשות:", self._buttons(d))
        await self._send_code(chat, d, f"{d.name}.py (מתוקן, לעיון)")
        return "תוקן, ממתין לאישור"

    async def _fix_running_plugin(self, chat: int, plugin: str) -> str:
        code = self.hub.plugins.files.get(plugin)
        if not code:
            return "התוסף כבר לא פעיל."
        tb, where = self.last_error.get(plugin, ("", ""))
        d = self._new_draft(plugin, code, f"תיקון באג בתוסף {plugin}", "user")
        d.orig_code = code
        d.issues = [Issue("high", f"קרס בזמן ריצה ב-{where}", tb[-500:], "הפעולה נכשלת למשתמשים", source="sandbox")]
        return await self._autofix(chat, d)

    # ------------------------------------------------------------------ install / versions / rollback
    async def _install(self, chat: int, d: Draft) -> str:
        if blocks_install(d.issues):
            return "יש ממצא קריטי, אי אפשר להתקין."
        parent = self.store.active()
        files = dict(self.hub.plugins.files)
        files[d.name] = d.code
        try:
            await self.hub.plugins.activate(files)           # validates first, swaps only if it loads
        except PluginLoadError as e:
            await self._say(chat, f"❌ ההתקנה נכשלה וכלום לא השתנה: {e.message}")
            return "נכשל"
        n = self.store.create(files, d.description, d.source, parent)
        self.store.set_active(n)
        self.activated_at = time.time()
        self.drafts.pop(d.id, None)
        cmds = [f"/{c}" for c, v in self.hub.plugins.registry.commands.items() if v[0] == d.name]
        menu = [m[0] for m in self.hub.plugins.registry.menu if m[1] == d.name]
        await self._say(chat, f"✅ הותקן. גרסה {label(n)} פעילה.\n"
                              + (f"פקודות חדשות: {' '.join(cmds)}\n" if cmds else "")
                              + (f"כפתורים בתפריט (/menu): {', '.join(menu)}\n" if menu else "")
                              + f"\nלחזור אחורה: /rollback  (או /rollback {label(parent)})")
        return f"גרסה {label(n)}"

    async def rollback(self, chat: int, arg: str = "") -> str:
        active = self.store.active()
        if arg:
            target = parse_label(arg)
            if target is None:
                await self._say(chat, "פורמט גרסה לא תקין. דוגמה: /rollback 0.3")
                return "פורמט שגוי"
        else:
            cur = self.store.get(active)
            if active == 0 or not cur:
                await self._say(chat, "אתה כבר בגרסה הבסיסית (0.0), אין לאן לחזור.")
                return "אין לאן"
            target = cur["parent"]
        if target == active:
            await self._say(chat, f"גרסה {label(target)} כבר פעילה.")
            return "כבר פעילה"
        try:
            await self.hub.plugins.activate(self.store.get_files(target))
        except KeyError:
            await self._say(chat, f"גרסה {label(target)} לא קיימת. /versions להצגת הרשימה.")
            return "לא קיימת"
        except PluginLoadError as e:
            await self._say(chat, f"❌ לא הצלחתי לטעון את {label(target)}, נשארתי בגרסה {label(active)}: {e.message}")
            return "נכשל"
        self.store.set_active(target)
        self.activated_at = time.time()
        await self._say(chat, f"↩️ חזרתי לגרסה {label(target)}. (הגרסה {label(active)} נשמרה וניתן לחזור אליה עם /rollback {label(active)})")
        return f"גרסה {label(target)}"

    async def cmd_versions(self, chat: int) -> None:
        active = self.store.active()
        rows = self.store.list()
        lines = [f"📦 גרסאות (פעילה: {label(active)})\n",
                 f"{'▶️' if active == 0 else '  '} 0.0 · הבוט הבסיסי, בלי תוספים"]
        for v in rows[:25]:
            when = time.strftime("%d/%m %H:%M", time.localtime(v["created"]))
            lines.append(f"{'▶️' if v['n'] == active else '  '} {v['label']} {SRC_ICON.get(v['source'], '')} · "
                         f"{when} · {v['description'][:60]}")
        lines.append("\nלחזרה לגרסה: /rollback 0.3")
        await self._say(chat, "\n".join(lines))

    async def cmd_version(self, chat: int) -> None:
        reg = self.hub.plugins.registry
        cmds = ", ".join(f"/{c}" for c in reg.commands) or "אין"
        await self._say(chat, f"גרסה פעילה: {self.active_label()}\nתוספים: {', '.join(reg.plugins) or 'אין'}\n"
                              f"פקודות מתוספים: {cmds}")

    # ------------------------------------------------------------------ safety net
    async def on_plugin_error(self, plugin: str, exc: BaseException, where: str) -> None:
        await self.hub.monitor.report(exc, where, plugin)
        now = time.time()
        recent = [t for t in self.hub.plugins.errors if now - t < AUTO_ROLLBACK_WINDOW]
        active = self.store.active()
        if (len(recent) >= AUTO_ROLLBACK_ERRORS and active > 0 and now - self.activated_at < AUTO_ROLLBACK_AGE):
            parent = (self.store.get(active) or {}).get("parent", 0)
            try:
                await self.hub.plugins.activate(self.store.get_files(parent))
            except (PluginLoadError, KeyError):
                return
            self.store.set_active(parent)
            self.activated_at = now
            await self._admins(f"🛡 הגרסה {label(active)} גרמה ל-{len(recent)} שגיאות תוך דקות ספורות. "
                               f"החזרתי אוטומטית לגרסה {label(parent)}. אפשר לחזור אליה עם /rollback {label(active)}.")

    # ------------------------------------------------------------------ /check
    async def cmd_check(self, chat: int, quick: bool = False) -> None:
        await self._say(chat, "🔍 בודק… (זה יכול לקחת עד דקה)")
        lines: list[str] = []
        # 1. core compiles
        bad = []
        for p in sorted((ROOT / "app").rglob("*.py")):
            try:
                compile(p.read_text(encoding="utf-8"), str(p), "exec")
            except SyntaxError as e:
                bad.append(f"{p.relative_to(ROOT)} שורה {e.lineno}: {e.msg}")
        lines.append("✅ קוד הליבה: כל הקבצים מתקמפלים" if not bad else
                     "🔴 קוד הליבה: שגיאות תחביר:\n" + "\n".join("   " + b for b in bad))
        # 2. the project's own tests, when present
        if not quick and (ROOT / "tests").is_dir():
            lines.append(await self._run_tests())
        elif quick:
            lines.append("⏭ דילגתי על הבדיקות האוטומטיות (/check בלי quick מריץ אותן)")
        # 3. every active plugin
        files = self.hub.plugins.files
        if not files:
            lines.append("ℹ️ אין תוספים פעילים (גרסה 0.0)")
        for name, code in files.items():
            issues = await check_plugin(code, name)
            if issues:
                lines.append(format_report(sort_issues(issues), name, used_ai=False))
            else:
                lines.append(f"✅ תוסף {name}: לא נמצאו באגים (סטטי + ניסוי)")
        await self._say(chat, "\n\n".join(lines))

    async def _run_tests(self) -> str:
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", cwd=str(ROOT),
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            out, _ = await asyncio.wait_for(proc.communicate(), 240)
        except asyncio.TimeoutError:
            proc.kill()
            return "🟡 בדיקות אוטומטיות: לא הסתיימו תוך 4 דקות"
        except OSError as e:
            return f"🟡 לא הצלחתי להריץ בדיקות: {e}"
        text = out.decode(errors="replace")
        ran = re.search(r"Ran (\d+) tests?", text)
        if proc.returncode == 0:
            return f"✅ בדיקות אוטומטיות: {ran.group(1) if ran else '?'} עברו"
        fails = re.findall(r"^(?:FAIL|ERROR): (.+)$", text, re.M)[:6]
        return "🔴 בדיקות אוטומטיות נכשלו:\n" + "\n".join("   " + f for f in fails or ["(ראה לוג)"])
