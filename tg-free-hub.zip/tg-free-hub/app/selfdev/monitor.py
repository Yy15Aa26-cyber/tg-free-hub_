"""Runtime bug monitor: when something crashes, tell the admin WHAT broke and WHAT it affects (in Hebrew),
once per distinct bug, and offer the right buttons."""
import logging
import time
import traceback

from ..ai.router import AllProvidersFailed
from ..telegram import TGError
from . import codegen

log = logging.getLogger("monitor")

FALLBACK = {
    "KeyError": "ניסיון לקרוא ערך שלא קיים (מפתח חסר במילון או בנתונים).",
    "TypeError": "פעולה על ערך מהסוג הלא נכון (למשל חיבור טקסט למספר, או ערך ריק).",
    "AttributeError": "פנייה לתכונה או לפונקציה שאין באובייקט (לעיתים כי הערך ריק).",
    "ValueError": "ערך בפורמט לא תקין (למשל טקסט שלא ניתן להמיר למספר).",
    "IndexError": "פנייה לפריט שלא קיים ברשימה.",
    "ZeroDivisionError": "חלוקה באפס.",
    "NameError": "שימוש במשתנה שלא הוגדר.",
    "TimeoutError": "פעולה שלקחה יותר מדי זמן.",
    "RuntimeError": "שגיאה שהקוד עצמו זרק בכוונה (ראה את ההודעה).",
}


class Monitor:
    def __init__(self, hub):
        self.hub = hub
        self.seen: dict[str, float] = {}
        self.sent: list[float] = []

    async def report(self, exc: BaseException, where: str, plugin: str | None = None) -> None:
        tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        last = traceback.extract_tb(exc.__traceback__)[-1:] or []
        loc = f"{last[0].filename.split('/')[-1]}:{last[0].lineno}" if last else "?"
        sig = f"{type(exc).__name__}|{where}|{loc}"
        now = time.time()
        if now - self.seen.get(sig, 0) < 600:
            return
        self.seen[sig] = now
        self.sent = [t for t in self.sent if now - t < 3600]
        if len(self.sent) >= 8:
            return
        self.sent.append(now)

        sd = getattr(self.hub, "selfdev", None)
        if plugin and sd:
            sd.last_error[plugin] = (tb[-1500:], where)
        info, ai_used = None, False
        if self.hub.router.has_any_key():
            try:
                code = self.hub.plugins.files.get(plugin, "") if plugin else ""
                info, ai_used = await codegen.explain_error(self.hub.router, tb, where, code), True
            except (AllProvidersFailed, ValueError, KeyError, AttributeError):
                info = None
        if not info:
            info = {"bug": f"{type(exc).__name__}: {str(exc)[:200]}",
                    "where": f"{where} ({loc})",
                    "impact": FALLBACK.get(type(exc).__name__, "הפעולה שהתרחשה ברגע השגיאה נכשלה."),
                    "fix": "בדוק את הקלט והקוד בשורה המצוינת."}
        lines = [f"🐞 זיהיתי באג {'בתוסף ' + plugin if plugin else 'בקוד הבוט'}",
                 f"📍 איפה: {info['where'] or where}",
                 f"🔎 מה הבאג: {info['bug']}",
                 f"💥 על מה זה משפיע: {info['impact']}",
                 f"💡 תיקון מוצע: {info['fix']}"]
        if ai_used:
            lines.append("(ההסבר נכתב על ידי ה-AI ועשוי להיות לא מדויק)")
        markup = None
        if plugin and sd:
            rows = [[{"text": "🛠 תקן את התוסף (תקבל לאישור)", "callback_data": f"sd:fixplug:{plugin}"[:64]}]]
            if sd.store.active() > 0:
                rows.append([{"text": "↩️ חזור לגרסה הקודמת", "callback_data": "sd:rb:prev"}])
            markup = {"inline_keyboard": rows}
        else:
            lines.append("זה בקוד הליבה. הבוט לא משנה אותו בעצמו. שלח לי את הטקסט הזה ואתקן בקובץ חדש.")
        for a in sorted(self.hub.s.admin_ids):
            try:
                await self.hub.tg.send_message(a, "\n".join(lines), **({"reply_markup": markup} if markup else {}))
            except TGError as e:
                log.warning("monitor notify failed: %s", e)
