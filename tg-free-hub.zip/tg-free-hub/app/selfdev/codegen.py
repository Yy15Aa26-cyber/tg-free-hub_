"""LLM-powered parts of self-development: write a plugin, fix a plugin, review code, explain a crash."""
import difflib
import json
import re

from ..plugins.manager import NAME_RE, RESERVED_COMMANDS

API_DOC = '''
You write ONE python file that is a plugin for a Telegram bot. Rules:
- The file must define:  def register(api):   (a normal function, one parameter)
- Inside register call:
    api.command("name", handler, help="תיאור קצר", admin_only=False)   # adds /name. a-z0-9_ only
    api.callback(handler)           # handles button presses of this plugin (one handler per plugin)
    api.menu("🔧 תווית", command="name")   # or data="x"   -> adds a button to the /menu keyboard
    api.every(3600, handler)        # scheduled task, seconds >= 30
- EVERY handler is:  async def handler(ctx):   (must be async)
- ctx has:
    ctx.user_id, ctx.chat_id, ctx.args (str after the command), ctx.args_list, ctx.data (button data), ctx.is_admin
    await ctx.reply("text", buttons=[[("label", "data")], [("site", "https://...")]])   # rows of (label, data|url)
    await ctx.ai("prompt")            -> str   (asks the bot's AI)
    await ctx.http_get("https://...") -> str   (safe GET, public sites only)
    ctx.search("query")               -> list of dicts {id, name, size_h, kind}
    await ctx.send_file(file_id)      (send a library file by its id)
    ctx.store_get("key", default) / ctx.store_set("key", json_serialisable_value)   (persistent per plugin)
    await ctx.notify_admins("text")
- Button presses arrive in the plugin's api.callback handler as ctx.data (the "data" you gave in buttons).
- Allowed imports ONLY: json re math datetime time random itertools collections functools typing asyncio string
  textwrap html base64 hashlib uuid decimal statistics zoneinfo enum dataclasses urllib.parse calendar.
- Do NOT use: os, sys, subprocess, open(), eval/exec, requests/httpx/urllib.request, threading, time.sleep.
- Always validate user input (empty args, wrong types) and reply to the user in Hebrew. Never leave a handler silent.
- Keep it small and readable. No global mutable state that is not saved with ctx.store_set.
'''

WRITE_SYSTEM = (
    "You are a careful senior Python engineer. " + API_DOC +
    "\nOutput format, exactly:\nNAME: <plugin_name a-z0-9_ 2-31 chars>\nSUMMARY: <one Hebrew sentence>\n"
    "```python\n<code>\n```\nNothing else."
)
FIX_SYSTEM = (
    "You fix bugs in a Telegram-bot plugin. " + API_DOC +
    "\nFix ONLY the listed problems and anything directly required by them; keep behaviour and names otherwise. "
    "Remove forbidden imports/calls by using the ctx helpers.\nOutput format, exactly:\nCHANGES:\n- <Hebrew: what you changed and why>\n"
    "- ...\n```python\n<the COMPLETE fixed file>\n```\nNothing else."
)
REVIEW_SYSTEM = (
    "You review Telegram-bot plugin code for REAL bugs only (logic errors, wrong API use, unhandled inputs, crashes, "
    "freezes, security). Do not nitpick style. Be honest about uncertainty. " + API_DOC +
    '\nReply with JSON only: {"issues":[{"severity":"critical|high|medium|low","title":"<Hebrew>","detail":"<Hebrew>",'
    '"impact":"<Hebrew: what this affects in practice>","line":<int or 0>}]}. Empty list if you find none.'
)
EXPLAIN_SYSTEM = (
    "You explain a Python crash to a non-expert bot owner, in Hebrew, briefly and concretely. "
    'Reply with JSON only: {"bug":"<what the bug is>","where":"<where>","impact":"<what it affects for users>",'
    '"fix":"<suggested fix>"}.'
)


class CodegenError(Exception):
    pass


def _extract_code(text: str) -> str:
    m = re.search(r"```(?:python|py)?\s*\n(.*?)```", text, re.S)
    if not m:
        raise CodegenError("ה-AI לא החזיר קוד. נסה לנסח מחדש.")
    return m.group(1).strip("\n") + "\n"


async def write_plugin(router, request: str, existing_name: str = "", existing_code: str = "",
                       taken: list[str] | None = None) -> tuple[str, str, str]:
    """Returns (name, summary, code)."""
    prompt = f"Request (Hebrew): {request}\n"
    if existing_code:
        prompt += (f"\nModify the existing plugin '{existing_name}'. Keep its NAME as '{existing_name}'. "
                   f"Current code:\n```python\n{existing_code}\n```\n")
    elif taken:
        prompt += f"\nThese plugin names already exist, do not reuse them: {', '.join(taken)}\n"
    prompt += f"Reserved command names you must not use: {', '.join(sorted(RESERVED_COMMANDS))}\n"
    res = await router.chat([{"role": "user", "content": prompt}], system=WRITE_SYSTEM, max_tokens=3500)
    m = re.search(r"NAME:\s*([A-Za-z0-9_]+)", res.text)
    name = (existing_name or (m.group(1).lower() if m else "")).strip()
    if not NAME_RE.match(name):
        name = "plugin_" + re.sub(r"\W", "", request.lower())[:10] or "plugin_x"
        name = re.sub(r"[^a-z0-9_]", "", name) or "plugin_new"
    s = re.search(r"SUMMARY:\s*(.+)", res.text)
    return name, (s.group(1).strip() if s else request[:100]), _extract_code(res.text)


async def fix_plugin(router, name: str, code: str, issues: list) -> tuple[str, list[str]]:
    """Returns (fixed_code, [Hebrew change notes])."""
    listing = "\n".join(f"- [{i.severity}] {i.title}" + (f" ({i.where})" if i.where else "") +
                        (f": {i.detail}" if i.detail else "") for i in issues)
    prompt = f"Plugin name: {name}\nProblems to fix:\n{listing}\n\nCurrent code:\n```python\n{code}\n```"
    res = await router.chat([{"role": "user", "content": prompt}], system=FIX_SYSTEM, max_tokens=3500)
    head = res.text.split("```", 1)[0]
    changes = [l.lstrip("-• ").strip() for l in head.splitlines() if l.strip().startswith(("-", "•"))]
    return _extract_code(res.text), changes or ["(ה-AI לא פירט שינויים. עיין בהשוואה)"]


async def ai_review(router, code: str, name: str, request: str = "") -> list:
    from .checker import Issue
    prompt = (f"Plugin '{name}'." + (f" The owner asked for: {request}\n" if request else "\n") +
              f"```python\n{code}\n```")
    res = await router.chat([{"role": "user", "content": prompt}], system=REVIEW_SYSTEM, max_tokens=1500)
    m = re.search(r"\{.*\}", res.text, re.S)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
    except ValueError:
        return []
    out = []
    for it in data.get("issues", [])[:8]:
        sev = it.get("severity", "medium")
        sev = sev if sev in ("critical", "high", "medium", "low") else "medium"
        if sev == "critical":     # an LLM guess must never block installation by itself
            sev = "high"
        line = it.get("line") or 0
        out.append(Issue(sev, str(it.get("title", ""))[:120], str(it.get("detail", ""))[:300],
                         str(it.get("impact", ""))[:300], f"שורה {line}" if line else "", "ai"))
    return out


async def explain_error(router, traceback_text: str, where: str, plugin_code: str = "") -> dict:
    prompt = f"Where: {where}\nTraceback:\n{traceback_text[-2500:]}\n"
    if plugin_code:
        prompt += f"Plugin code:\n```python\n{plugin_code[:6000]}\n```"
    res = await router.chat([{"role": "user", "content": prompt}], system=EXPLAIN_SYSTEM, max_tokens=500)
    m = re.search(r"\{.*\}", res.text, re.S)
    d = json.loads(m.group(0))
    return {k: str(d.get(k, ""))[:400] for k in ("bug", "where", "impact", "fix")}


def make_diff(old: str, new: str, max_lines: int = 60) -> str:
    lines = list(difflib.unified_diff(old.splitlines(), new.splitlines(), "לפני", "אחרי", lineterm="", n=1))
    if len(lines) > max_lines:
        lines = lines[:max_lines] + [f"... (עוד {len(lines) - max_lines} שורות בקובץ המלא)"]
    return "\n".join(lines)
