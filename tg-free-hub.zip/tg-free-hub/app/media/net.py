"""Downloading from links: direct files (stdlib, size-capped, SSRF-safe) and sites via yt-dlp."""
import asyncio
import ipaddress
import os
import re
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request

from .common import MediaError, have, run, safe_name

DIRECT_EXT = re.compile(
    r"\.(zip|rar|7z|tar|gz|pdf|epub|mp4|mkv|webm|mov|avi|mp3|m4a|flac|wav|ogg|jpg|jpeg|png|gif|webp|apk|iso|exe|txt|csv|docx?|xlsx?|pptx?)$", re.I)


def check_url(url: str, allow_private: bool = False) -> str:
    """Only public http(s) hosts. Blocks localhost / LAN / cloud-metadata addresses."""
    u = urllib.parse.urlparse(url.strip())
    if u.scheme not in ("http", "https") or not u.hostname:
        raise MediaError("הקישור חייב להתחיל ב-http:// או https://")
    if u.username or u.password:
        raise MediaError("קישור עם שם משתמש וסיסמה לא נתמך")
    if allow_private:
        return u.geturl()
    try:
        infos = socket.getaddrinfo(u.hostname, u.port or (443 if u.scheme == "https" else 80))
    except socket.gaierror:
        raise MediaError("לא ניתן לפתור את כתובת האתר")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global:
            raise MediaError("כתובות פנימיות אסורות")
    return u.geturl()


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, allow_private):
        self.allow_private = allow_private

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(newurl, self.allow_private)  # every hop is re-validated
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _filename(resp, url: str) -> str:
    cd = resp.headers.get("Content-Disposition", "")
    m = re.search(r"filename\*=UTF-8''([^;]+)", cd) or re.search(r'filename="?([^";]+)"?', cd)
    if m:
        return safe_name(urllib.parse.unquote(m.group(1)))
    path = urllib.parse.unquote(urllib.parse.urlparse(url).path)
    return safe_name(os.path.basename(path) or "download")


def _direct_blocking(url: str, dest_dir: str, max_bytes: int, allow_private: bool, progress) -> str:
    opener = urllib.request.build_opener(_SafeRedirect(allow_private))
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (hub-downloader)"})
    try:
        resp = opener.open(req, timeout=30)
    except urllib.error.HTTPError as e:
        raise MediaError(f"האתר החזיר שגיאה {e.code}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise MediaError(f"לא הצלחתי להתחבר: {getattr(e, 'reason', e)}")
    with resp:
        ctype = resp.headers.get_content_type()
        if ctype == "text/html":
            raise MediaError("הקישור מוביל לדף אינטרנט ולא לקובץ")
        total = int(resp.headers.get("Content-Length") or 0)
        if total and total > max_bytes:
            raise MediaError(f"הקובץ גדול מדי ({total // 2**20}MB). המגבלה היא {max_bytes // 2**20}MB")
        path = os.path.join(dest_dir, _filename(resp, resp.geturl()))
        done = 0
        with open(path, "wb") as f:
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                done += len(chunk)
                if done > max_bytes:
                    f.close()
                    os.remove(path)
                    raise MediaError(f"הקובץ חורג מהמגבלה ({max_bytes // 2**20}MB)")
                f.write(chunk)
                progress(done, total)
    return path


async def download_direct(url, dest_dir, max_mb, progress=lambda d, t: None, allow_private=False) -> str:
    check_url(url, allow_private)
    return await asyncio.to_thread(_direct_blocking, url, dest_dir, max_mb * 2**20, allow_private, progress)


async def download_ytdlp(url, dest_dir, max_mb, audio_only=False) -> str:
    try:
        import yt_dlp  # noqa: F401
    except ImportError:
        raise MediaError("yt-dlp לא מותקן בשרת")
    check_url(url)
    cmd = [sys.executable, "-m", "yt_dlp", "--no-playlist", "--no-warnings", "--max-filesize", f"{max_mb}M",
           "-o", os.path.join(dest_dir, "%(title).80s.%(ext)s"), "--print", "after_move:filepath"]
    if audio_only:
        cmd += ["-x", "--audio-format", "mp3"]
    else:
        cmd += ["-f", "bv*[height<=720]+ba/b[height<=720]/b", "--merge-output-format", "mp4"]
    out, _ = await run(cmd + [url], timeout=1500)
    lines = [l for l in out.strip().splitlines() if l.strip()]
    if not lines or not os.path.exists(lines[-1]):
        raise MediaError("לא נמצא וידאו להורדה בקישור (או שהוא חורג ממגבלת הגודל)")
    return lines[-1]


async def fetch(url, dest_dir, max_mb, audio_only=False, progress=lambda d, t: None, allow_private=False) -> str:
    """Direct file link -> stdlib downloader. Anything else -> yt-dlp."""
    check_url(url, allow_private)
    if DIRECT_EXT.search(urllib.parse.urlparse(url).path):
        return await download_direct(url, dest_dir, max_mb, progress, allow_private)
    return await download_ytdlp(url, dest_dir, max_mb, audio_only)


async def split_video(path: str, max_bytes: int = 45 * 2**20, hard_limit: int = 49 * 2**20) -> list[str]:
    """Cut a video into parts that fit the Bot API upload limit (no re-encode)."""
    from .common import probe_duration
    if not have("ffmpeg"):
        raise MediaError("ffmpeg לא מותקן")
    size = os.path.getsize(path)
    dur = await probe_duration(path)
    parts = max(2, -(-size // max_bytes) + 1)  # one spare part: keyframes make parts uneven
    seg = max(5, int(dur / parts))
    base, ext = os.path.splitext(path)
    pattern = f"{base}.part%02d{ext}"
    await run(["ffmpeg", "-y", "-i", path, "-c", "copy", "-map", "0", "-f", "segment",
               "-segment_time", str(seg), "-reset_timestamps", "1", pattern], 900)
    out = sorted(p for p in os.listdir(os.path.dirname(path)) if ".part" in p and p.startswith(os.path.basename(base)))
    files = [os.path.join(os.path.dirname(path), p) for p in out]
    if any(os.path.getsize(p) > hard_limit for p in files):
        raise MediaError("לא הצלחתי לפצל את הסרטון לחלקים קטנים מספיק")
    return files


async def cut_clip(path: str, start: str, end: str, out_path: str) -> str:
    for t in (start, end):
        if not re.fullmatch(r"\d{1,2}(:\d{2}){0,2}(\.\d+)?", t):
            raise MediaError("פורמט זמן לא תקין. דוגמאות: 90, 1:30, 01:02:03")
    await run(["ffmpeg", "-y", "-ss", start, "-to", end, "-i", path, "-c:v", "libx264", "-preset", "veryfast",
               "-crf", "26", "-c:a", "aac", "-movflags", "+faststart", out_path], 900)
    return out_path


def split_file_blocking(path: str, part_bytes: int) -> list[str]:
    """Binary split into name.001, name.002 ... (join later with: cat name.* > name)."""
    parts, buf = [], 8 * 2**20
    with open(path, "rb") as src:
        i = 0
        while True:
            i += 1
            out = f"{path}.{i:03d}"
            written = 0
            with open(out, "wb") as dst:
                while written < part_bytes:
                    chunk = src.read(min(buf, part_bytes - written))
                    if not chunk:
                        break
                    dst.write(chunk)
                    written += len(chunk)
            if written == 0:
                os.remove(out)
                break
            parts.append(out)
            if written < part_bytes:
                break
    return parts


async def split_file(path: str, part_bytes: int) -> list[str]:
    return await asyncio.to_thread(split_file_blocking, path, part_bytes)
