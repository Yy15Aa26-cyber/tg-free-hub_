import asyncio
import os
import shutil


class MediaError(Exception):
    """Error with a message that is safe to show to the user."""


async def run(cmd: list[str], timeout: float = 900) -> tuple[str, str]:
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        proc.kill()
        await proc.wait()
        raise
    if proc.returncode != 0:
        tail = err.decode(errors="replace").strip().splitlines()[-3:]
        raise MediaError(f"{os.path.basename(cmd[0])} failed: " + " | ".join(tail)[:300])
    return out.decode(errors="replace"), err.decode(errors="replace")


def have(binary: str) -> bool:
    return shutil.which(binary) is not None


async def probe_duration(path: str) -> float:
    out, _ = await run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", path], 60)
    try:
        return float(out.strip().splitlines()[0])
    except (ValueError, IndexError):
        raise MediaError("could not read media duration")


def safe_name(name: str, default: str = "file") -> str:
    keep = "".join(c if (c.isalnum() or c in " ._-()[]") else "_" for c in name).strip(" .")
    return keep[:100] or default
