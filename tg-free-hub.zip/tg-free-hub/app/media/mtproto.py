"""Optional big-file uploader (up to 2GB) over MTProto, using the SAME bot token + api_id/api_hash
from my.telegram.org. Needs: pip install pyrogram tgcrypto. Without it, files over 50MB are split (videos) or refused."""
import os

_client = None


def configured(api_id: int, api_hash: str) -> bool:
    if not (api_id and api_hash):
        return False
    try:
        import pyrogram  # noqa: F401
        return True
    except ImportError:
        return False


async def send_big(api_id: int, api_hash: str, bot_token: str, chat_id: int, path: str,
                   caption: str = "", as_video: bool = False) -> dict:
    global _client
    from pyrogram import Client
    if _client is None:
        _client = Client("hub-mtproto", api_id=api_id, api_hash=api_hash, bot_token=bot_token, in_memory=True)
        await _client.start()
    if as_video:
        m = await _client.send_video(chat_id, path, caption=caption[:1000], supports_streaming=True)
        media = m.video
    else:
        m = await _client.send_document(chat_id, path, caption=caption[:1000], file_name=os.path.basename(path))
        media = m.document
    return {"message_id": m.id, "chat": {"id": chat_id},
            "document" if not as_video else "video": {
                "file_id": media.file_id, "file_unique_id": media.file_unique_id,
                "file_name": getattr(media, "file_name", None) or os.path.basename(path),
                "file_size": media.file_size, "mime_type": media.mime_type}}
