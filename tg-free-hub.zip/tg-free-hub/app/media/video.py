"""AI video maker: topic -> script (via the AI router) -> narration (edge-tts, free) -> slides (Pillow)
-> MP4 (ffmpeg). Vertical 720x1280, ready for Shorts / Reels / TikTok."""
import asyncio
import json
import os
import re
import wave
from dataclasses import dataclass

from PIL import Image, ImageDraw, ImageFont, features

from .common import MediaError, have, probe_duration, run

W, H, FPS = 720, 1280, 25
VOICES = {"he": "he-IL-AvriNeural", "en": "en-US-AriaNeural", "ar": "ar-EG-SalmaNeural",
          "ru": "ru-RU-SvetlanaNeural", "es": "es-ES-ElviraNeural", "fr": "fr-FR-DeniseNeural"}
LANG_NAMES = {"he": "Hebrew", "en": "English", "ar": "Arabic", "ru": "Russian", "es": "Spanish", "fr": "French"}
RTL = {"he", "ar"}
PALETTES = [((20, 33, 61), (11, 110, 110)), ((46, 16, 80), (192, 57, 43)), ((15, 52, 67), (200, 140, 30)),
            ((30, 30, 46), (30, 100, 180)), ((54, 33, 20), (30, 130, 90))]
FONT_CANDIDATES = [
    os.environ.get("FONT_PATH", ""),
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/noto/NotoSansHebrew-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/system/fonts/NotoSansHebrew-Bold.ttf",       # Android ships a Hebrew font
    "/system/fonts/NotoSansHebrew-Regular.ttf",
    "/system/fonts/DroidSansHebrew-Bold.ttf",
]


@dataclass
class Script:
    title: str
    description: str
    hashtags: list[str]
    scenes: list[dict]   # {"text": on-screen, "narration": spoken}
    lang: str = "he"


# ------------------------------------------------------------------ script
def parse_script(raw: str, lang: str) -> Script:
    m = re.search(r"\{.*\}", raw or "", re.S)
    if not m:
        raise MediaError("ה-AI לא החזיר תסריט תקין. נסה שוב.")
    try:
        d = json.loads(m.group(0))
        scenes = [{"text": str(s["text"]).strip()[:140], "narration": str(s.get("narration") or s["text"]).strip()[:500]}
                  for s in d["scenes"] if str(s.get("text", "")).strip()]
    except (ValueError, KeyError, TypeError, AttributeError):
        raise MediaError("ה-AI החזיר תסריט במבנה לא תקין. נסה שוב.")
    if len(scenes) < 2:
        raise MediaError("התסריט קצר מדי. נסה נושא אחר.")
    tags = [("#" + str(t).lstrip("#").replace(" ", "")) for t in d.get("hashtags", [])][:8]
    return Script(str(d.get("title", ""))[:100], str(d.get("description", ""))[:500], tags, scenes[:12], lang)


async def write_script(router, topic: str, lang: str = "he", scenes: int = 6, style: str = "") -> Script:
    name = LANG_NAMES.get(lang, lang)
    prompt = (
        f"Write a short vertical video script about: {topic}\n"
        f"Language: {name}. Exactly {scenes} scenes. Style: {style or 'engaging, clear, factual'}.\n"
        "Scene 1 is a strong hook. The last scene is a call to action.\n"
        'Reply with JSON only, no markdown: {"title": str, "description": str, "hashtags": [str], '
        '"scenes": [{"text": "short on-screen text (max 12 words)", "narration": "spoken sentence(s), 15-35 words"}]}')
    res = await router.chat([{"role": "user", "content": prompt}], system="You output only valid JSON.", max_tokens=1800)
    return parse_script(res.text, lang)


# ------------------------------------------------------------------ narration
def _silence(path: str, seconds: float) -> None:
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
        w.writeframes(b"\x00\x00" * int(22050 * seconds))


async def tts(text: str, lang: str, out_base: str, voice: str | None = None) -> str:
    """Returns an audio file. Falls back to silence (video is still produced) if edge-tts is unavailable."""
    try:
        import edge_tts
        path = out_base + ".mp3"
        await asyncio.wait_for(edge_tts.Communicate(text, voice or VOICES.get(lang, VOICES["en"])).save(path), 60)
        if os.path.getsize(path) > 1000:
            return path
    except Exception:  # noqa: BLE001 - any TTS failure -> silent fallback
        pass
    path = out_base + ".wav"
    _silence(path, max(2.5, len(text.split()) * 0.38))
    return path


# ------------------------------------------------------------------ slides
def _font(size: int) -> ImageFont.FreeTypeFont:
    for p in FONT_CANDIDATES:
        if p and os.path.exists(p):
            return ImageFont.truetype(p, size)
    raise MediaError("לא נמצא פונט. הגדר FONT_PATH לקובץ TTF שתומך בעברית.")


def _visual(line: str, rtl: bool) -> str:
    """Without libraqm, reorder RTL text ourselves: reverse the line, keep Latin/digit runs readable."""
    if not rtl or features.check("raqm"):
        return line
    runs = re.findall(r"[A-Za-z0-9][A-Za-z0-9.,:%/+-]*|[^A-Za-z0-9]+", line)
    out = []
    for r in reversed(runs):
        out.append(r if re.match(r"[A-Za-z0-9]", r) else r[::-1])
    return "".join(out)


def render_slide(text: str, idx: int, total: int, path: str, rtl: bool, brand: str = "") -> None:
    top, bottom = PALETTES[idx % len(PALETTES)]
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    for y in range(H):
        t = y / (H - 1)
        d.line([(0, y), (W, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)))
    kw = {"direction": "rtl"} if rtl and features.check("raqm") else {}
    maxw, size = W - 120, 78
    while True:
        f = _font(size)
        lines, cur = [], ""
        for word in text.split():
            trial = (cur + " " + word).strip()
            if f.getlength(trial) <= maxw or not cur:
                cur = trial
            else:
                lines.append(cur); cur = word
        lines.append(cur)
        lh = int(size * 1.35)
        if (len(lines) * lh <= 760 and all(f.getlength(l) <= maxw for l in lines)) or size <= 34:
            break
        size -= 4
    y = (H - len(lines) * lh) // 2
    for l in lines:
        s = _visual(l, rtl)
        x = (W - f.getlength(s)) / 2
        d.text((x + 3, y + 3), s, font=f, fill=(0, 0, 0), **kw)   # soft shadow keeps text legible on any palette
        d.text((x, y), s, font=f, fill=(255, 255, 255), **kw)
        y += lh
    d.rounded_rectangle([60, H - 70, W - 60, H - 62], 4, fill=(120, 140, 160))
    d.rounded_rectangle([60, H - 70, 60 + int((W - 120) * (idx + 1) / total), H - 62], 4, fill=(255, 255, 255))
    if brand:
        bf = _font(30)
        b = _visual(brand, rtl)
        d.text(((W - bf.getlength(b)) / 2, 70), b, font=bf, fill=(255, 255, 255), **kw)
    img.save(path)


# ------------------------------------------------------------------ assemble
async def make_video(script: Script, workdir: str, voice: str | None = None, brand: str = "",
                     progress=lambda msg: None) -> str:
    if not have("ffmpeg"):
        raise MediaError("ffmpeg לא מותקן בשרת")
    rtl = script.lang in RTL
    clips = []
    n = len(script.scenes)
    for i, sc in enumerate(script.scenes):
        progress(f"סצנה {i + 1} מתוך {n}")
        img, audio = os.path.join(workdir, f"s{i}.png"), None
        render_slide(sc["text"], i, n, img, rtl, brand)
        audio = await tts(sc["narration"], script.lang, os.path.join(workdir, f"a{i}"), voice)
        dur = (await probe_duration(audio)) + 0.5
        frames = int(dur * FPS)
        clip = os.path.join(workdir, f"c{i}.mp4")
        vf = (f"scale={W * 2}:{H * 2},zoompan=z='min(zoom+0.0007,1.12)':d={frames}"
              f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s={W}x{H}:fps={FPS},format=yuv420p")
        await run(["ffmpeg", "-y", "-i", img, "-i", audio, "-vf", vf, "-af", "apad", "-t", f"{dur:.2f}",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-c:a", "aac", "-b:a", "96k",
                   "-ar", "44100", "-ac", "1", clip], 600)
        clips.append(clip)
    lst = os.path.join(workdir, "list.txt")
    with open(lst, "w") as f:
        f.writelines(f"file '{c}'\n" for c in clips)
    out = os.path.join(workdir, "video.mp4")
    progress("מחבר את הסצנות")
    await run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart", out], 300)
    return out


def caption_for(script: Script) -> str:
    parts = [script.title, "", script.description, "", " ".join(script.hashtags)]
    return "\n".join(p for p in parts).strip()[:1000]
