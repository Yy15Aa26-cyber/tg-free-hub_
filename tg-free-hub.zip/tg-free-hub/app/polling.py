"""Long-polling mode: no public URL needed (ideal for running on a phone in Termux or on a home PC)."""
import asyncio
import logging

from .telegram import TG, TGError

log = logging.getLogger("poll")
ALLOWED = ["message", "callback_query", "channel_post"]


async def poll_once(bot, tg: TG, offset: int, timeout: int = 30) -> int:
    updates = await tg.call("getUpdates", http_timeout=timeout + 15, timeout=timeout, offset=offset,
                            allowed_updates=ALLOWED)
    tasks = []
    for u in updates:
        offset = max(offset, u["update_id"] + 1)
        tasks.append(asyncio.create_task(bot.handle(u)))
    return offset


async def poll_loop(bot, tg: TG) -> None:
    try:
        await tg.call("deleteWebhook")
    except TGError as e:
        log.error("deleteWebhook failed: %s", e)
    offset = 0
    while True:
        try:
            offset = await poll_once(bot, tg, offset)
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001 - network drops are normal on a phone
            log.warning("poll error: %s", e)
            await asyncio.sleep(5)


async def setup_commands(tg: TG) -> None:
    try:
        await tg.call("setMyCommands", commands=[
            {"command": "search", "description": "חיפוש קבצים וסרטונים"},
            {"command": "video", "description": "יצירת סרטון קצר עם AI"},
            {"command": "dl", "description": "הורדה מקישור"},
            {"command": "jobs", "description": "המשימות שלי"},
            {"command": "ai", "description": "שאלה לעוזר ה-AI"},
            {"command": "reset", "description": "ניקוי הקשר השיחה"},
            {"command": "help", "description": "עזרה"},
        ])
    except TGError as e:
        log.error("setMyCommands failed: %s", e)
