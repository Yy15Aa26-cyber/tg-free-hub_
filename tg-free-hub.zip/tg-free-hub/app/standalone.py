"""Bot-only mode: `python -m app.standalone`. No FastAPI, no public URL, no web server.
Everything works from the chat (search, AI, /addkey, /dl, /clip, /video, /backup) - perfect for Termux.
Install: pip install httpx cryptography Pillow yt-dlp   (+ edge-tts for voice)"""
import asyncio
import logging
import os

import httpx

from .ai.router import AIRouter
from .bot import Bot
from .config import load_settings
from .db import DB
from .hub import Hub
from .jobs import Jobs
from .polling import poll_loop, setup_commands
from .telegram import TG

log = logging.getLogger("standalone")


async def backup_loop(hub: Hub, bot: Bot) -> None:
    admin = sorted(hub.s.admin_ids)[0]
    while True:
        await asyncio.sleep(3600)
        try:
            if hub.db.dirty:
                await bot.send_backup(admin)
        except Exception as e:  # noqa: BLE001
            log.warning("auto-backup failed: %s", e)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    s = load_settings()
    if not s.bot_token or not s.admin_ids:
        raise SystemExit("חסרים BOT_TOKEN ו-ADMIN_IDS. ראה .env.example")
    async with httpx.AsyncClient() as http:
        db = DB(s.db_path)
        tg = TG(s.bot_token, http)
        router = AIRouter(db, s.secret_key, http, s.ai_timeout)
        hub = Hub(s, db, tg, router)
        hub.jobs = Jobs(hub)
        bot = Bot(hub)
        await hub.selfdev.boot()
        if s.ai_keys_seed and not db.meta_get("seeded"):
            router.seed(s.ai_keys_seed)
            db.meta_set("seeded", "1")
        await setup_commands(tg)
        me = await tg.call("getMe")
        log.info("bot @%s is running (polling). Ctrl+C to stop.", me.get("username"))
        await asyncio.gather(poll_loop(bot, tg), backup_loop(hub, bot))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
