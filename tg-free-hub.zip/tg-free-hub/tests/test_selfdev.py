import asyncio
import json
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests import _httpx_stub  # noqa: E402

_httpx_stub.install()
from app.bot import Bot  # noqa: E402
from app.config import Settings  # noqa: E402
from app.db import DB  # noqa: E402
from app.hub import Hub  # noqa: E402
from app.jobs import Jobs  # noqa: E402
from app.plugins.manager import PluginLoadError, PluginManager  # noqa: E402
from app.selfdev import checker  # noqa: E402
from app.selfdev.versions import label, parse_label  # noqa: E402
from tests.test_core import FakeClient, FakeTG  # noqa: E402
from app.ai.router import AIRouter  # noqa: E402

GOOD = '''
async def hello(ctx):
    name = ctx.args.strip() or "חבר"
    n = (ctx.store_get("n", 0) or 0) + 1
    ctx.store_set("n", n)
    await ctx.reply(f"שלום {name}! פעם מספר {n}", buttons=[[("עוד", "again")]])

async def on_button(ctx):
    await ctx.reply("לחצת: " + ctx.data)

def register(api):
    api.command("hello", hello, help="ברכה")
    api.callback(on_button)
    api.menu("👋 שלום", command="hello")
'''
GOOD2 = GOOD.replace('"hello"', '"hi2"').replace("שלום {name}", "היי {name}")
NAMEERR = '''
async def tip(ctx):
    await ctx.reply(mesage_text)

def register(api):
    api.command("tip", tip)
'''
KEYERR = '''
async def boom(ctx):
    data = {"a": 1}
    await ctx.reply(str(data["missing"]))

def register(api):
    api.command("boom", boom, help="קורס")
'''
HANG = '''
import asyncio
async def stuck(ctx):
    await asyncio.sleep(100)
    await ctx.reply("x")

def register(api):
    api.command("stuck", stuck)
'''


def run(c):
    return asyncio.run(c)


class FakeTG3(FakeTG):
    def __init__(self):
        super().__init__()
        self.docs = []

    async def send_document_bytes(self, chat_id, filename, data, caption=""):
        self.docs.append((chat_id, filename, data.decode(), caption))


class FakeRes:
    def __init__(self, text):
        self.text, self.provider, self.model, self.attempts = text, "fake", "m", []


class FakeRouter:
    """Answers by the kind of system prompt it receives."""

    def __init__(self, write="", fix="", review='{"issues": []}', explain=None, has_key=True):
        self.write, self.fix, self.review, self.has_key = write, fix, review, has_key
        self.explain = explain or json.dumps({"bug": "מפתח חסר במילון", "where": "boom", "impact": "הפקודה קורסת",
                                              "fix": "להשתמש ב-get"}, ensure_ascii=False)
        self.calls = []

    def has_any_key(self):
        return self.has_key

    async def chat(self, messages, system="", only_provider=None, max_tokens=1024):
        self.calls.append(system[:30])
        if "senior Python engineer" in system:
            return FakeRes(self.write)
        if "You fix bugs" in system:
            return FakeRes(self.fix)
        if "review Telegram-bot plugin" in system:
            return FakeRes(self.review)
        if "explain a Python crash" in system:
            return FakeRes(self.explain)
        return FakeRes("שלום")


def make_hub(router=None):
    s = Settings(bot_token="1:T", admin_ids={1}, allowed_ids={2}, secret_key="k")
    db = DB(":memory:")
    tg = FakeTG3()
    hub = Hub(s, db, tg, router or FakeRouter())
    hub.jobs = Jobs(hub)
    return hub


def code_reply(name, code, summary="סיכום"):
    return f"NAME: {name}\nSUMMARY: {summary}\n```python\n{code}\n```"


class VersionTests(unittest.TestCase):
    def test_numbering_rule(self):
        got = [label(n) for n in (1, 2, 9, 10, 11, 19, 20)]
        self.assertEqual(got, ["0.1", "0.2", "0.9", "1.0", "1.1", "1.9", "2.0"])
        self.assertEqual([parse_label(x) for x in ("0.1", "1.0", "v1.1", "2.0")], [1, 10, 11, 20])
        self.assertIsNone(parse_label("abc"))


class StaticTests(unittest.TestCase):
    def titles(self, code):
        return [(i.severity, i.title) for i in checker.static_check(code, "p")]

    def test_clean_plugin_has_no_findings(self):
        self.assertEqual(checker.static_check(GOOD, "hello"), [])

    def test_finds_known_problems(self):
        self.assertEqual(self.titles("def register(api:\n")[0][0], "critical")
        self.assertIn("critical", [s for s, _ in self.titles("x = 1\n")])                       # no register
        self.assertTrue(any("mesage_text" in t for _, t in self.titles(NAMEERR)))
        self.assertTrue(any("sleep" in t for _, t in self.titles(
            "import time\nasync def h(ctx):\n    time.sleep(3)\ndef register(api):\n    api.command('x', h)\n")))
        self.assertTrue(any("אינסופית" in t for _, t in self.titles(
            "async def h(ctx):\n    while True:\n        x = 1\ndef register(api):\n    api.command('x', h)\n")))
        self.assertTrue(any(s == "security" for s, _ in self.titles("import os\ndef register(api):\n    pass\n")))
        self.assertTrue(any(s == "security" for s, _ in self.titles("def register(api):\n    eval('1')\n")))
        self.assertTrue(any("שמורה" in t for _, t in self.titles(
            "async def h(ctx): pass\ndef register(api):\n    api.command('start', h)\n")))

    def test_issue_carries_impact_text(self):
        i = [x for x in checker.static_check(NAMEERR, "p") if "mesage_text" in x.title][0]
        self.assertIn("NameError", i.impact)
        self.assertIn("שורה 3", i.where)


class SandboxTests(unittest.TestCase):
    def test_good_plugin_runs_clean(self):
        self.assertEqual(run(checker.sandbox_check(GOOD, "hello")), [])

    def test_runtime_bug_found_with_line(self):
        issues = run(checker.sandbox_check(KEYERR, "boom"))
        self.assertTrue(issues)
        self.assertIn("KeyError", issues[0].title)
        self.assertIn("שורה 4", issues[0].where)

    def test_hanging_handler_detected(self):
        t0 = time.time()
        issues = run(checker.sandbox_check(HANG, "stuck"))
        self.assertTrue(any("תקועה" in i.title for i in issues))
        self.assertLess(time.time() - t0, 20)

    def test_sandbox_has_no_secrets_in_env(self):
        os.environ["BOT_TOKEN"] = "SECRET-TOKEN-123"
        try:
            leak = ("import os\nasync def h(ctx):\n    await ctx.reply(os.environ.get('BOT_TOKEN', 'none'))\n"
                    "def register(api):\n    api.command('leak', h)\n")
            # run the harness directly and look at what the plugin could see
            from app.selfdev.checker import HARNESS
            import subprocess
            env = {k: os.environ[k] for k in ("PATH",) if k in os.environ}
            out = subprocess.run([sys.executable, "-I", str(HARNESS)], input=json.dumps(
                {"code": leak.replace("await ctx.reply(os.environ.get('BOT_TOKEN', 'none'))",
                                      "assert 'BOT_TOKEN' not in os.environ"), "name": "leak", "reserved": []}),
                capture_output=True, text=True, env=env).stdout
            findings = json.loads(out.strip().splitlines()[-1])["findings"]
            self.assertEqual([f for f in findings if f["kind"] != "silent"], [])   # no assertion error = env was clean
        finally:
            os.environ.pop("BOT_TOKEN")


class ManagerTests(unittest.TestCase):
    def test_load_dispatch_and_buttons(self):
        hub = make_hub()

        async def go():
            await hub.plugins.activate({"hello": GOOD})
            self.assertTrue(await hub.plugins.dispatch_command("hello", 2, 2, "דני"))
            await hub.plugins.dispatch_callback("hello", 2, 2, "again")
            self.assertFalse(await hub.plugins.dispatch_command("nope", 2, 2, ""))
        run(go())
        self.assertIn("שלום דני! פעם מספר 1", hub.tg.sent[0][1])
        kb = hub.tg.sent[0][2]["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual(kb["callback_data"], "x:hello:again")
        self.assertEqual(hub.tg.sent[1][1], "לחצת: again")
        self.assertEqual(hub.plugins.menu_rows(False)[0][0]["callback_data"], "x:hello:cmd:hello")

    def test_bad_plugins_are_rejected_without_changing_running_set(self):
        hub = make_hub()

        async def go():
            await hub.plugins.activate({"hello": GOOD})
            for bad in ("def register(api:\n", "x=1\n", "def register(api):\n    api.command('start', None)\n",
                        "def register(api):\n    def h(ctx): pass\n    api.command('sync', h)\n"):
                with self.assertRaises(PluginLoadError):
                    await hub.plugins.activate({"hello": GOOD, "bad": bad})
            self.assertEqual(hub.plugins.registry.plugins, ["hello"])
        run(go())

    def test_plugin_crash_never_kills_bot_and_is_reported(self):
        hub = make_hub()
        seen = []

        async def on_err(plugin, exc, where):
            seen.append((plugin, type(exc).__name__, where))
        hub.plugins.on_error = on_err

        async def go():
            await hub.plugins.activate({"boom": KEYERR})
            await hub.plugins.dispatch_command("boom", 2, 2, "")
        run(go())
        self.assertEqual(seen, [("boom", "KeyError", "/boom")])
        self.assertIn("אירעה שגיאה בתוסף", hub.tg.sent[-1][1])


class FlowTests(unittest.TestCase):
    def test_upgrade_install_versions_rollback(self):
        hub = make_hub(FakeRouter(write=code_reply("hello", GOOD, "פקודת ברכה")))
        sd = hub.selfdev

        async def go():
            await sd.cmd_upgrade(1, 1, "תוסיף פקודת ברכה /hello עם כפתור")
            report = hub.tg.sent[-1]
            self.assertIn("לא מצאתי באגים", report[1])
            data = [b["callback_data"] for row in report[2]["reply_markup"]["inline_keyboard"] for b in row]
            self.assertTrue(any(d.startswith("sd:inst:") for d in data))
            self.assertEqual(hub.plugins.registry.commands, {})                       # nothing installed yet
            await sd.on_callback(1, 1, next(d for d in data if d.startswith("sd:inst:")))
            self.assertEqual(sd.active_label(), "0.1")
            self.assertIn("hello", hub.plugins.registry.commands)

            hub.router.write = code_reply("greet2", GOOD2, "ברכה שנייה")
            await sd.cmd_upgrade(1, 1, "עוד ברכה בשם אחר")
            inst = [b["callback_data"] for row in hub.tg.sent[-1][2]["reply_markup"]["inline_keyboard"] for b in row
                    if b["callback_data"].startswith("sd:inst:")][0]
            await sd.on_callback(1, 1, inst)
            self.assertEqual(sd.active_label(), "0.2")
            self.assertEqual(sorted(hub.plugins.registry.commands), ["hello", "hi2"])

            await sd.rollback(1, "")                                                  # previous
            self.assertEqual(sd.active_label(), "0.1")
            self.assertEqual(sorted(hub.plugins.registry.commands), ["hello"])
            await sd.rollback(1, "0.2")                                               # and forward again
            self.assertEqual(sorted(hub.plugins.registry.commands), ["hello", "hi2"])
            await sd.rollback(1, "0.0")                                               # base bot
            self.assertEqual(hub.plugins.registry.commands, {})
            await sd.cmd_versions(1)
            text = hub.tg.sent[-1][1]
            self.assertIn("0.1", text)
            self.assertIn("0.2", text)
            self.assertIn("▶️ 0.0", text)
        run(go())

    def test_tenth_install_is_version_1_0_and_eleventh_is_1_1(self):
        hub = make_hub()
        seen = []

        async def go():
            for i in range(11):
                d = hub.selfdev._new_draft(f"p{i}", GOOD.replace('"hello"', f'"c{i}"'), "x", "user")
                await hub.selfdev.on_callback(1, 1, f"sd:inst:{d.id}")
                seen.append(hub.selfdev.active_label())
        run(go())
        self.assertEqual(seen, ["0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1"])

    def test_addcode_bug_report_then_autofix_needs_approval_then_install(self):
        fixed = NAMEERR.replace("mesage_text", '"טיפ"')
        router = FakeRouter(fix="CHANGES:\n- תיקנתי את השם mesage_text למחרוזת קבועה\n```python\n" + fixed + "\n```")
        hub = make_hub(router)
        sd = hub.selfdev

        async def go():
            await sd.cmd_addcode(1, 1, "tipper", NAMEERR)
            rep = hub.tg.sent[-1][1]
            self.assertIn("mesage_text", rep)
            self.assertIn("NameError", rep)                                            # what it affects
            self.assertIn("משפיע על", rep)
            btns = [b["callback_data"] for row in hub.tg.sent[-1][2]["reply_markup"]["inline_keyboard"] for b in row]
            did = btns[0].split(":")[2]
            self.assertTrue(any(b.startswith("sd:fix:") for b in btns) and any(b.startswith("sd:self:") for b in btns))
            await sd.on_callback(1, 1, f"sd:fix:{did}")
            msgs = " ".join(m[1] for m in hub.tg.sent[-3:])
            self.assertIn("תיקנתי את השם", msgs)                                       # list of what was fixed
            self.assertIn("-", msgs)                                                    # diff shown
            self.assertEqual(sd.store.active(), 0)                                      # NOT installed without approval
            self.assertEqual(hub.tg.docs[-1][1], "tipper.py")                           # fixed code delivered for review
            self.assertIn('"טיפ"', hub.tg.docs[-1][2])
            await sd.on_callback(1, 1, f"sd:inst:{did}")
            self.assertEqual(sd.active_label(), "0.1")
            self.assertIn("tip", hub.plugins.registry.commands)
        run(go())

    def test_user_fixes_it_himself(self):
        hub = make_hub()

        async def go():
            await hub.selfdev.cmd_addcode(1, 1, "tipper", NAMEERR)
            did = hub.selfdev.drafts and next(iter(hub.selfdev.drafts))
            await hub.selfdev.on_callback(1, 1, f"sd:self:{did}")
            self.assertEqual(hub.tg.docs[-1][1], "tipper.py")
            self.assertIn("/addcode tipper", hub.tg.sent[-1][1])
            # he edits and re-sends -> checked again, now clean
            await hub.selfdev.cmd_addcode(1, 1, "tipper", NAMEERR.replace("mesage_text", '"טיפ"'))
            self.assertIn("לא מצאתי באגים", hub.tg.sent[-1][1])
        run(go())

    def test_critical_code_cannot_be_installed(self):
        hub = make_hub()

        async def go():
            await hub.selfdev.cmd_addcode(1, 1, "broken", "def register(api:\n")
            btns = [b["callback_data"] for row in hub.tg.sent[-1][2]["reply_markup"]["inline_keyboard"] for b in row]
            self.assertFalse(any(b.startswith("sd:inst:") for b in btns))
            did = btns[0].split(":")[2]
            await hub.selfdev.on_callback(1, 1, f"sd:inst:{did}")
            self.assertEqual(hub.selfdev.store.active(), 0)
        run(go())

    def test_auto_rollback_after_repeated_errors(self):
        hub = make_hub()

        async def go():
            await hub.selfdev.on_callback(1, 1, f"sd:inst:{hub.selfdev._new_draft('hello', GOOD, 'x', 'user').id}")
            d = hub.selfdev._new_draft("boom", KEYERR, "x", "user")
            await hub.selfdev.on_callback(1, 1, f"sd:inst:{d.id}")
            self.assertEqual(hub.selfdev.active_label(), "0.2")
            for _ in range(3):
                await hub.plugins.dispatch_command("boom", 2, 2, "")
            self.assertEqual(hub.selfdev.active_label(), "0.1")                       # went back by itself
            self.assertNotIn("boom", hub.plugins.registry.commands)
            self.assertTrue(any("החזרתי אוטומטית" in m[1] for m in hub.tg.sent))
        run(go())

    def test_boot_falls_back_when_active_version_is_corrupt(self):
        hub = make_hub()
        st = hub.selfdev.store
        good = st.create({"hello": GOOD}, "ok", "user", 0)
        bad = st.create({"hello": GOOD, "x": "def register(api:\n"}, "bad", "user", good)
        st.set_active(bad)

        async def go():
            await hub.selfdev.boot()
        run(go())
        self.assertEqual(st.active(), good)
        self.assertIn("hello", hub.plugins.registry.commands)
        self.assertTrue(any("חזרתי אוטומטית" in m[1] for m in hub.tg.sent))


class MonitorTests(unittest.TestCase):
    def test_reports_what_and_impact_dedupes_and_offers_buttons(self):
        hub = make_hub()

        async def go():
            await hub.selfdev.on_callback(1, 1, f"sd:inst:{hub.selfdev._new_draft('boom', KEYERR, 'x', 'user').id}")
            await hub.plugins.dispatch_command("boom", 2, 2, "")
            await hub.plugins.dispatch_command("boom", 2, 2, "")                        # same bug again: no second alert
        run(go())
        alerts = [m for m in hub.tg.sent if "זיהיתי באג" in m[1]]
        self.assertEqual(len(alerts), 1)
        text = alerts[0][1]
        for word in ("מה הבאג", "על מה זה משפיע", "איפה", "תיקון מוצע"):
            self.assertIn(word, text)
        data = [b["callback_data"] for r in alerts[0][2]["reply_markup"]["inline_keyboard"] for b in r]
        self.assertIn("sd:fixplug:boom", data)
        self.assertIn("sd:rb:prev", data)

    def test_works_without_ai_key(self):
        hub = make_hub(FakeRouter(has_key=False))

        async def go():
            await hub.plugins.activate({"boom": KEYERR})
            await hub.plugins.dispatch_command("boom", 2, 2, "")
        run(go())
        text = [m for m in hub.tg.sent if "זיהיתי באג" in m[1]][0][1]
        self.assertIn("KeyError", text)
        self.assertIn("ניסיון לקרוא ערך שלא קיים", text)

    def test_core_crash_is_reported_and_marked_as_core(self):
        hub = make_hub()
        bot = Bot(hub)

        async def go():
            async def bad_cb(*a, **k):
                raise ZeroDivisionError("x")
            bot.on_message = bad_cb
            await bot.handle({"message": {"chat": {"type": "private", "id": 1}, "from": {"id": 1}, "text": "hi"}})
        run(go())
        text = [m for m in hub.tg.sent if "זיהיתי באג" in m[1]][0][1]
        self.assertIn("בקוד הבוט", text)
        self.assertIn("קוד הליבה", text)


class BotCommandTests(unittest.TestCase):
    def test_commands_admin_only_and_plugin_commands_work(self):
        hub = make_hub(FakeRouter(write=code_reply("hello", GOOD)))
        bot = Bot(hub)

        def msg(uid, text):
            return {"message": {"message_id": 5, "chat": {"id": uid, "type": "private"}, "from": {"id": uid}, "text": text}}

        async def go():
            await bot.handle(msg(2, "/upgrade משהו חדש וגדול"))                        # non-admin
            self.assertIn("פקודה לא מוכרת", hub.tg.sent[-1][1])
            await bot.handle(msg(1, "/addcode hello\n```python\n" + GOOD + "\n```"))
            did = next(iter(hub.selfdev.drafts))
            await bot.handle({"callback_query": {"id": "c", "from": {"id": 1}, "data": f"sd:inst:{did}",
                                                 "message": {"chat": {"id": 1}}}})
            await bot.handle(msg(2, "/hello דני"))                                      # regular user uses the new command
            self.assertIn("שלום דני", hub.tg.sent[-1][1])
            await bot.handle(msg(2, "/menu"))
            kb = hub.tg.sent[-1][2]["reply_markup"]["inline_keyboard"]
            self.assertTrue(any("👋 שלום" == b["text"] for row in kb for b in row))
            await bot.handle({"callback_query": {"id": "c2", "from": {"id": 2}, "data": "x:hello:cmd:hello",
                                                 "message": {"chat": {"id": 2}}}})
            self.assertIn("שלום חבר", hub.tg.sent[-1][1])
            await bot.handle(msg(1, "/rollback"))
            await bot.handle(msg(2, "/hello"))
            self.assertIn("פקודה לא מוכרת", hub.tg.sent[-1][1])
            await bot.handle(msg(1, "/version"))
            self.assertIn("0.0", hub.tg.sent[-1][1])
        run(go())

    def test_py_file_upload_with_caption(self):
        hub = make_hub()
        bot = Bot(hub)

        async def fake_download(file_id):
            return GOOD.encode()
        hub.tg.download = fake_download

        async def go():
            await bot.handle({"message": {"message_id": 7, "chat": {"id": 1, "type": "private"}, "from": {"id": 1},
                                          "caption": "/addcode my_hello", "document": {
                                              "file_id": "F", "file_unique_id": "U", "file_name": "x.py", "file_size": 300}}})
        run(go())
        self.assertIn("לא מצאתי באגים", hub.tg.sent[-1][1])
        self.assertIn("my_hello", next(iter(hub.selfdev.drafts.values())).name)


class AiReviewTests(unittest.TestCase):
    def test_ai_findings_are_labelled_and_never_block_install(self):
        review = json.dumps({"issues": [{"severity": "critical", "title": "לוגיקה שגויה", "detail": "d",
                                         "impact": "i", "line": 3}]}, ensure_ascii=False)
        router = FakeRouter(review=review)
        issues = run(checker.check_plugin(GOOD, "hello", router))
        self.assertEqual(len(issues), 1)
        self.assertEqual((issues[0].source, issues[0].severity), ("ai", "high"))
        self.assertFalse(checker.blocks_install(issues))
        self.assertIn("הערכת AI", checker.format_report(issues, "hello"))


class BackupKeepsVersionsTests(unittest.TestCase):
    def test_restore_brings_back_versions_and_active_pointer(self):
        import tempfile
        hub = make_hub()
        n = hub.selfdev.store.create({"hello": GOOD}, "x", "user", 0)
        hub.selfdev.store.set_active(n)
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "b.db")
            hub.db.snapshot(p)
            fresh = DB(":memory:")
            fresh.restore_from(p)
        from app.selfdev.versions import VersionStore
        vs = VersionStore(fresh)
        self.assertEqual(vs.active(), 1)
        self.assertIn("hello", vs.get_files(1))


if __name__ == "__main__":
    unittest.main(verbosity=2)
