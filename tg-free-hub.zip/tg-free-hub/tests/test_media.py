import asyncio
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests import _httpx_stub  # noqa: E402

_httpx_stub.install()
from app.ai.router import AIRouter  # noqa: E402
from app.config import Settings  # noqa: E402
from app.db import DB  # noqa: E402
from app.hub import Hub  # noqa: E402
from app.jobs import Jobs, JobError  # noqa: E402
from app.media import net, video  # noqa: E402
from app.media.common import MediaError  # noqa: E402
from tests.test_core import FakeClient, FakeTG, R  # noqa: E402


class FakeTG2(FakeTG):
    def __init__(self):
        super().__init__()
        self.files = []

    async def send_file_path(self, chat_id, path, caption="", as_video=False):
        self.files.append({"chat": chat_id, "name": os.path.basename(path), "size": os.path.getsize(path),
                           "caption": caption, "video": as_video})
        return {"message_id": 77, "chat": {"id": chat_id}, "document": {
            "file_id": "FID", "file_unique_id": "UID" + str(len(self.files)), "file_name": os.path.basename(path),
            "file_size": os.path.getsize(path)}}


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/page":
            body, ct = b"<html>hi</html>", "text/html"
        elif self.path == "/big.bin":
            body, ct = os.urandom(3 * 2**20), "application/octet-stream"
        else:
            body, ct = b"hello-file-content", "application/pdf"
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        if self.path.endswith("report.pdf"):
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''%D7%93%D7%95%D7%97.pdf")
        self.end_headers()
        self.wfile.write(body)


class NetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        self.d = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def test_ssrf_blocked(self):
        for bad in ("http://127.0.0.1/x", "http://169.254.169.254/latest/meta-data", "http://10.0.0.5/a",
                    "http://[::1]/", "file:///etc/passwd", "ftp://x/y", "http://user:pw@example.com/a"):
            with self.assertRaises(MediaError, msg=bad):
                net.check_url(bad)

    def test_direct_download_and_filename(self):
        p = asyncio.run(net.download_direct(self.base + "/report.pdf", self.d, 5, allow_private=True))
        self.assertEqual(os.path.basename(p), "דוח.pdf")
        self.assertEqual(open(p, "rb").read(), b"hello-file-content")

    def test_size_cap_and_html_rejected(self):
        with self.assertRaises(MediaError) as cm:
            asyncio.run(net.download_direct(self.base + "/big.bin", self.d, 1, allow_private=True))
        self.assertIn("1MB", str(cm.exception))
        self.assertEqual(os.listdir(self.d), [])
        with self.assertRaises(MediaError):
            asyncio.run(net.download_direct(self.base + "/page", self.d, 5, allow_private=True))

    def test_clip_time_validation(self):
        with self.assertRaises(MediaError):
            asyncio.run(net.cut_clip("x.mp4", "1;30", "2:00", "o.mp4"))
        with self.assertRaises(MediaError):
            asyncio.run(net.cut_clip("x.mp4", "-5", "2:00", "o.mp4"))


SCRIPT = json.dumps({"title": "טיפים", "description": "תיאור", "hashtags": ["חיסכון", "#tips"],
                     "scenes": [{"text": "3 טיפים לחיסכון", "narration": "שלום לכולם"},
                                {"text": "טיפ ראשון: תקציב", "narration": "קודם תקציב"},
                                {"text": "עקבו!", "narration": "עקבו"}]}, ensure_ascii=False)


class VideoTests(unittest.TestCase):
    def test_parse_script(self):
        s = video.parse_script("blah ```json\n" + SCRIPT + "\n``` bye", "he")
        self.assertEqual(len(s.scenes), 3)
        self.assertEqual(s.hashtags, ["#חיסכון", "#tips"])
        for bad in ("no json here", '{"scenes": "x"}', '{"scenes":[{"text":"only one"}]}'):
            with self.assertRaises(MediaError):
                video.parse_script(bad, "he")

    def test_real_render_produces_vertical_mp4(self):
        d = tempfile.mkdtemp()
        try:
            out = asyncio.run(video.make_video(video.parse_script(SCRIPT, "he"), d))
            self.assertGreater(os.path.getsize(out), 10_000)
            dur = asyncio.run(video.probe_duration(out))
            self.assertGreater(dur, 5)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_split_video(self):
        d = tempfile.mkdtemp()
        try:
            out = asyncio.run(video.make_video(video.parse_script(SCRIPT, "he"), d))
            parts = asyncio.run(net.split_video(out, max_bytes=40_000))
            self.assertGreaterEqual(len(parts), 2)
        finally:
            shutil.rmtree(d, ignore_errors=True)


class JobTests(unittest.TestCase):
    def setUp(self):
        self.s = Settings(bot_token="1:T", admin_ids={1}, allowed_ids={2}, secret_key="k")
        self.db = DB(":memory:")
        self.tg = FakeTG2()
        self.client = FakeClient([("groq", [R(200, {"choices": [{"message": {"content": SCRIPT}}]})])])
        self.router = AIRouter(self.db, "k", self.client, 5)
        self.router.add_from_preset("groq", "gsk_key_aaaa1")
        self.hub = Hub(self.s, self.db, self.tg, self.router)
        self.hub.jobs = Jobs(self.hub)

    def test_video_job_end_to_end(self):
        async def go():
            j = self.hub.jobs.start_video(2, "חיסכון בכסף", "he", 3)
            await j.task
            return j
        j = asyncio.run(go())
        self.assertEqual(j.status, "done", j.detail)
        f = self.tg.files[0]
        self.assertTrue(f["video"] and f["chat"] == 2 and f["caption"].startswith("טיפים"))
        self.assertIn("✅", self.tg.sent[-1][1])

    def test_permissions_and_limits(self):
        with self.assertRaises(JobError):
            self.hub.jobs.start_download(2, "https://example.com/a.zip")  # not admin
        with self.assertRaises(MediaError):
            self.hub.jobs.start_download(1, "http://127.0.0.1/a.zip")      # SSRF, rejected before queueing
        with self.assertRaises(JobError):
            self.hub.jobs.start_video(2, "x")

    def test_download_job_indexes_into_library(self):
        async def fake_fetch(url, d, mb, audio=False, progress=lambda a, b: None):
            p = os.path.join(d, "movie.mp4")
            open(p, "wb").write(b"0" * 5000)
            return p
        orig, orig_check = net.fetch, net.check_url
        net.fetch, net.check_url = fake_fetch, lambda u, allow_private=False: u   # offline sandbox: no DNS
        try:
            async def go():
                j = self.hub.jobs.start_download(1, "https://example.com/watch?v=1")
                await j.task
                return j
            j = asyncio.run(go())
        finally:
            net.fetch, net.check_url = orig, orig_check
        self.assertEqual(j.status, "done", j.detail)
        from app import files as filelib
        self.assertEqual(filelib.search(self.db, "movie")[0]["name"], "movie.mp4")

    def test_big_file_without_mtproto_is_split_into_parts(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "huge.zip")
        data = os.urandom(2**20)
        with open(p, "wb") as f:
            for _ in range(100):
                f.write(data)                        # 100MB
        try:
            sent = asyncio.run(self.hub.jobs.deliver(1, p, "x"))
            self.assertEqual(len(sent), 3)           # 100MB / ~46MB
            self.assertTrue(all(f["size"] <= 49 * 2**20 for f in self.tg.files))
            self.assertIn("cat huge.zip.*", self.tg.files[0]["caption"])
            joined = b"".join(open(os.path.join(d, f["name"]), "rb").read() for f in self.tg.files)
            self.assertEqual(joined, open(p, "rb").read())   # parts re-join to the exact original
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_too_many_parts_without_mtproto_gives_clear_error(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "huge.zip")
        with open(p, "wb") as f:
            f.truncate(2 * 2**30)                    # sparse 2GB -> ~46 parts
        try:
            with self.assertRaises(MediaError) as cm:
                asyncio.run(self.hub.jobs.deliver(1, p, "x"))
            self.assertIn("TG_API_ID", str(cm.exception))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_unlimited_settings(self):
        self.hub.s.ai_rate_per_min = 0
        self.hub.s.max_active_jobs = 0
        for _ in range(50):
            self.hub.rate_limit(5)

    def test_cancel_and_failure_notifies(self):
        self.client.routes = [("groq", [R(500, {"error": {"message": "boom"}})])]
        async def go():
            j = self.hub.jobs.start_video(2, "נושא כלשהו", "he", 3)
            await j.task
            return j
        j = asyncio.run(go())
        self.assertEqual(j.status, "failed")
        self.assertIn("❌", self.tg.sent[-1][1])


if __name__ == "__main__":
    unittest.main(verbosity=2)


class PollingTests(unittest.TestCase):
    def test_poll_once_dispatches_and_advances_offset(self):
        from app.bot import Bot
        from app.polling import poll_once

        class T(FakeTG2):
            async def call(self, method, **p):
                self.calls.append((method, p))
                if method == "getUpdates":
                    return [{"update_id": 10, "message": {"message_id": 1, "chat": {"id": 1, "type": "private"},
                                                          "from": {"id": 1}, "text": "/reset"}}]
                return {}

        s = Settings(bot_token="1:T", admin_ids={1}, secret_key="k")
        db, tg = DB(":memory:"), T()
        hub = Hub(s, db, tg, AIRouter(db, "k", FakeClient([])))
        hub.jobs = Jobs(hub)

        async def go():
            off = await poll_once(Bot(hub), tg, 0, timeout=1)
            await asyncio.sleep(0.05)
            return off
        self.assertEqual(asyncio.run(go()), 11)
        self.assertEqual(tg.calls[0][1]["offset"], 0)
        self.assertIn("נוקה", tg.sent[-1][1])

    def test_standalone_does_not_need_fastapi(self):
        import importlib
        sys.modules.pop("fastapi", None)
        importlib.import_module("app.standalone")
        self.assertNotIn("fastapi", sys.modules)
