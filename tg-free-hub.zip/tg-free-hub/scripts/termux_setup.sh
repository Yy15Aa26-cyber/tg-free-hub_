#!/data/data/com.termux/files/usr/bin/bash
# התקנה ל-Termux. הרצה:  bash scripts/termux_setup.sh
set -e
cd "$(dirname "$0")/.."
echo "== מתקין חבילות מערכת"
pkg update -y && pkg upgrade -y
pkg install -y python ffmpeg git python-pillow
pkg install -y python-cryptography || pip install cryptography
echo "== מתקין ספריות פייתון"
pip install httpx yt-dlp
echo "== מתקין pyrogram להעלאת קבצים עד 2GB"
pkg install -y clang make || true
pip install pyrogram tgcrypto || pip install pyrogram || echo "!! pyrogram לא הותקן: קבצים גדולים יפוצלו לחלקים"
pip install edge-tts || echo "!! edge-tts לא הותקן: הסרטונים ייווצרו בלי קריינות (טקסט על המסך בלבד)"

echo "== מחפש פונט עברי לסרטונים"
FONT=""
for f in /system/fonts/NotoSansHebrew-Bold.ttf /system/fonts/NotoSansHebrew-Regular.ttf /system/fonts/DroidSansHebrew-Bold.ttf; do
  [ -f "$f" ] && FONT="$f" && break
done
[ -z "$FONT" ] && FONT=$(find /system/fonts "$PREFIX/share/fonts" -iname '*hebrew*' -o -iname 'DejaVuSans-Bold.ttf' 2>/dev/null | head -1)

if [ ! -f .env ]; then
  cp .env.example .env
  KEY=$(python -c "import secrets;print(secrets.token_urlsafe(32))")
  sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$KEY|" .env
  sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=|" .env
  echo "נוצר .env עם SECRET_KEY אקראי. שמור גיבוי שלו!"
fi
mkdir -p "$HOME/work"
sed -i "s|^WORK_DIR=.*|WORK_DIR=$HOME/work|" .env
# מצב ללא הגבלה (0 = בלי מגבלה)
for kv in MAX_DOWNLOAD_MB=0 AI_RATE_PER_MIN=0 MAX_ACTIVE_JOBS=0; do
  k=${kv%%=*}; grep -q "^$k=" .env && sed -i "s|^$k=.*|$kv|" .env || echo "$kv" >> .env
done
[ -n "$FONT" ] && sed -i "s|^FONT_PATH=.*|FONT_PATH=$FONT|" .env && echo "פונט: $FONT" || echo "!! לא נמצא פונט. הגדר FONT_PATH ב-.env ידנית"
echo
echo "עכשיו ערוך את .env:  nano .env   (BOT_TOKEN, ADMIN_IDS)"
echo "ואז הפעל:  bash scripts/termux_run.sh"
