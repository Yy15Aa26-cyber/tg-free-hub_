#!/data/data/com.termux/files/usr/bin/bash
# הרצת הבוט ב-Termux (מצב Polling, בלי שרת ובלי כתובת ציבורית)
cd "$(dirname "$0")/.."
command -v termux-wake-lock >/dev/null && termux-wake-lock   # מונע מאנדרואיד להרדים את התהליך
set -a; . ./.env; set +a
export PUBLIC_URL=""
while true; do                       # אם הבוט קורס או הרשת נופלת: עולה מחדש
  python -m app.standalone
  echo "הבוט נעצר. מפעיל מחדש בעוד 5 שניות (Ctrl+C ליציאה)"; sleep 5
done
